package com.examly.springapp.service;

import com.examly.springapp.model.Booking;
import com.examly.springapp.model.Room;
import com.examly.springapp.repository.BookingRepository;
import com.examly.springapp.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private RoomRepository roomRepository;

    public Booking createBooking(Long roomId, String guestName, String guestEmail,
    LocalDate checkIn, LocalDate checkOut) {

        Optional<Room> roomOptional = roomRepository.findById(roomId);
        if (!roomOptional.isPresent()) {
            return null; 
        }

        Room room = roomOptional.get();

        if (!room.getAvailable()) {
            return null; 
        }

        double totalPrice = ChronoUnit.DAYS.between(checkIn, checkOut) * room.getPrice();

        Booking booking = new Booking();
        booking.setRoom(room);
        booking.setGuestName(guestName);
        booking.setGuestEmail(guestEmail);
        booking.setCheckInDate(checkIn);
        booking.setCheckOutDate(checkOut);
        booking.setTotalPrice(totalPrice);
        booking.setStatus("PENDING");
        booking.setCreatedAt(LocalDate.now());

        return bookingRepository.save(booking);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Booking getBookingById(Long id) {
        Optional<Booking> bookingOptional = bookingRepository.findById(id);
        return bookingOptional.orElse(null); // return null if not found
    }

    public Booking updateStatus(Long id, String status) {
        Optional<Booking> bookingOptional = bookingRepository.findById(id);
        if (!bookingOptional.isPresent()) {
            return null;
        }

        Booking booking = bookingOptional.get();

        if (!status.equals("APPROVED") && !status.equals("REJECTED")) {
            return null;
        }

        booking.setStatus(status);

        Room room = booking.getRoom();
        room.setAvailable(status.equals("REJECTED"));
        roomRepository.save(room);

        return bookingRepository.save(booking);
        }
        }
       