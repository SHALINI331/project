// package com.examly.springapp.service;
// import com.examly.springapp.model.User;
// import com.examly.springapp.repository.UserRepository;
// import org.springframework.stereotype.Service;

// import java.util.List;
// import java.util.Optional;

// @Service
// public class UserService {

//     private final UserRepository userRepository;

//     public UserService(UserRepository userRepository) {
//         this.userRepository = userRepository;
//         }

//         public User registerUser(User user) {
//             return userRepository.save(user);
//             }

//             public Optional<User> login(String email, String password) {
//                 return userRepository.findByEmail(email)
//                 .filter(u -> u.getPassword().equals(password));
//             }

//             public List<User> getAllUsers() {
//                 return userRepository.findAll();
//             }
//             }
        
package com.examly.springapp.service;

import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository userRepository;
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
        }

        // Register with role
        public User registerUser(User user) {
            if (user.getRole() == null || user.getRole().isEmpty()) {
                user.setRole("USER"); // default role
                }
                return userRepository.save(user);
                }

                // Login with role check
                public Optional<User> login(String email, String password, String role) {
                    return userRepository.findByEmailAndPasswordAndRole(email, password, role);
                }

                public List<User> getAllUsers() {
                    return userRepository.findAll();
                }
                }
               