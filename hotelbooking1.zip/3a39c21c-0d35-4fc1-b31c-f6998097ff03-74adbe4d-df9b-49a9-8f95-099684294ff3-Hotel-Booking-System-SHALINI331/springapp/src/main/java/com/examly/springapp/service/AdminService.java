// package com.examly.springapp.service;

// import com.examly.springapp.model.Admin;
// import com.examly.springapp.model.Room;
// import com.examly.springapp.repository.AdminRepository;
// import com.examly.springapp.repository.RoomRepository;
// import com.examly.springapp.exception.RoomNotFoundException;
// import org.springframework.stereotype.Service;

// import java.util.List;
// import java.util.Optional;

// @Service
// public class AdminService {

//     private final AdminRepository adminRepository;
//     private final RoomRepository roomRepository;

//     public AdminService(AdminRepository adminRepository, RoomRepository roomRepository) {
//         this.adminRepository = adminRepository;
//         this.roomRepository = roomRepository;
//     }

//     public Optional<Admin> login(String email, String password) {
//         return adminRepository.findByEmail(email).filter(a -> a.getPassword().equals(password));
//         }

//         public List<Room> getAllRooms() {
//             return roomRepository.findAll();
//         }

//         public List<Room> getAvailableRooms() {
//             return roomRepository.findByAvailableTrue();
//         }

//         public Optional<Room> getRoomById(Long id) {
//             return roomRepository.findById(id);
//             }

//             public Room createRoom(Room room) {
//                 return roomRepository.save(room);
//                 }

//                 public Room updateRoom(Long id, Room updatedRoom) {
//                     Room existingRoom = roomRepository.findById(id)
//                     .orElseThrow(() -> new RoomNotFoundException(id));

//                     existingRoom.setRoomNumber(updatedRoom.getRoomNumber());
//                     existingRoom.setRoomType(updatedRoom.getRoomType());
//                     existingRoom.setPrice(updatedRoom.getPrice());
//                     existingRoom.setCapacity(updatedRoom.getCapacity());
//                     existingRoom.setAvailable(updatedRoom.getAvailable());

//                     return roomRepository.save(existingRoom);
//                     }

//                     public void deleteRoom(Long id) {
//                         Room room = roomRepository.findById(id)
//                         .orElseThrow(() -> new RoomNotFoundException(id));
//                         roomRepository.delete(room);
//                         }
// }

package com.examly.springapp.service;

import com.examly.springapp.model.Admin;
import com.examly.springapp.model.Room;
import com.examly.springapp.model.Booking;
import com.examly.springapp.repository.AdminRepository;
import com.examly.springapp.repository.RoomRepository;
import com.examly.springapp.repository.BookingRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    private final AdminRepository adminRepository;
    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;

    public AdminService(AdminRepository adminRepository,
            RoomRepository roomRepository,
            BookingRepository bookingRepository) {
        this.adminRepository = adminRepository;
        this.roomRepository = roomRepository;
        this.bookingRepository = bookingRepository;
    }

    // // ==================== ADMIN LOGIN ====================
    public Optional<Admin> login(String email, String password) {
        return adminRepository.findByEmail(email);
    }

    public Admin register(Admin admin) {
        return adminRepository.save(admin);
    }
    
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    public List<Room> getAvailableRooms() {
        return roomRepository.findByAvailableTrue();
    }

    public Optional<Room> getRoomById(Long id) {
        return roomRepository.findById(id);
    }

    public Room createRoom(Room room) {
        return roomRepository.save(room);
    }

    public Room updateRoom(Long id, Room updatedRoom) {
        return roomRepository.findById(id)
                .map(room -> {
                    room.setRoomNumber(updatedRoom.getRoomNumber());
                    room.setRoomType(updatedRoom.getRoomType());
                    room.setPrice(updatedRoom.getPrice());
                    room.setCapacity(updatedRoom.getCapacity());
                    room.setAvailable(updatedRoom.getAvailable());
                    return roomRepository.save(room);
                })
                .orElseThrow(() -> new RuntimeException("Room not found with id " + id));
    }

    public void deleteRoom(Long id) {
        roomRepository.deleteById(id);
    }

   
    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }
}
