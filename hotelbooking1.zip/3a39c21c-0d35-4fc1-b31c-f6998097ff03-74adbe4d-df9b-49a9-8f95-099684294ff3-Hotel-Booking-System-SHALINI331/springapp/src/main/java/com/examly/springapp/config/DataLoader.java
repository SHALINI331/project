package com.examly.springapp.config;

import com.examly.springapp.model.Room;
import com.examly.springapp.repository.RoomRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;

@Configuration
public class DataLoader {

    @Bean
    public CommandLineRunner loadData(RoomRepository roomRepository) {
        return args -> {
            if (roomRepository.count() == 0) { // avoid duplicate loading on restart
                roomRepository.save(new Room(null, "101", "Single", 1500.0, 1, true));
                roomRepository.save(new Room(null, "102", "Double", 2500.0, 2, true));
                roomRepository.save(new Room(null, "103", "Suite", 5000.0, 4, false));
                roomRepository.save(new Room(null, "104", "Deluxe", 3500.0, 2, true));
                roomRepository.save(new Room(null, "105", "Single", 1500.0, 1, false));
                roomRepository.save(new Room(null, "106", "Double", 2500.0, 2, true));
                roomRepository.save(new Room(null, "107", "Suite", 5000.0, 4, true));
            }
        };
    }
}
