package com.examly.springapp.exception;

public class BookingRoomNotFoundException extends RuntimeException {
    public BookingRoomNotFoundException(Long roomId) {
        super("Booking not found with id: " + roomId);
    }
}
   