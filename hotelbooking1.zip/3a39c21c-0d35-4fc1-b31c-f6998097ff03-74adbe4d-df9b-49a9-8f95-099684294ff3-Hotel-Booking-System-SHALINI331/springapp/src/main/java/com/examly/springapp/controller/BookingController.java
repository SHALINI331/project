package com.examly.springapp.controller;

import com.examly.springapp.model.Booking;
import com.examly.springapp.model.Room;
import com.examly.springapp.repository.BookingRepository;
import com.examly.springapp.repository.RoomRepository;
import com.examly.springapp.exception.BookingRoomNotFoundException;
import com.examly.springapp.exception.RoomNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private RoomRepository roomRepository;

    @PostMapping
    public ResponseEntity<?> createBooking(@RequestBody Map<String, String> body) {
        try {
            if (!body.containsKey("roomId") || body.get("roomId") == null || body.get("roomId").isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("message", "Missing roomId in request"));
            }
            Long roomId;
            try {
                roomId = Long.parseLong(body.get("roomId"));
            } catch (NumberFormatException nfe) {
                return ResponseEntity.badRequest().body(Map.of("message", "Invalid roomId format"));
            }
            String guestName = body.get("guestName");
            String guestEmail = body.get("guestEmail");
            LocalDate checkInDate = LocalDate.parse(body.get("checkInDate"));
            LocalDate checkOutDate = LocalDate.parse(body.get("checkOutDate"));

            if (!guestEmail.contains("@") || !guestEmail.contains(".")) {
                return ResponseEntity.badRequest().body(Map.of("message", "Invalid email format"));
            }

            if (!checkOutDate.isAfter(checkInDate)) {
                return ResponseEntity.badRequest()
                        .body(Map.of("message", "Check-out date must be after check-in date"));
            }

            Room room = roomRepository.findById(roomId)
                    .orElseThrow(() -> new RoomNotFoundException(roomId));

            if (!room.getAvailable()) {
                return ResponseEntity.badRequest().body(Map.of("message", "Room is not available"));
            }

            long days = ChronoUnit.DAYS.between(checkInDate, checkOutDate);
            double totalPrice = days * room.getPrice();

            Booking booking = new Booking();
            booking.setRoom(room);
            booking.setGuestName(guestName);
            booking.setGuestEmail(guestEmail);
            booking.setCheckInDate(checkInDate);
            booking.setCheckOutDate(checkOutDate);
            booking.setTotalPrice(totalPrice);
            booking.setStatus("PENDING");
            booking.setCreatedAt(LocalDate.now());

            Booking savedBooking = bookingRepository.save(booking);
            return ResponseEntity.status(201).body(savedBooking);

        } catch (RoomNotFoundException ex) {
            throw ex; // Will be handled by GlobalExceptionHandler
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", "Invalid booking request"));
        }
    }

    @GetMapping
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getBookingById(@PathVariable Long id) {
        Booking booking = bookingRepository.findById(id).orElseThrow(() -> new BookingRoomNotFoundException(id));
        return ResponseEntity.ok(booking);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateBookingStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Booking booking = bookingRepository.findById(id).orElseThrow(() -> new BookingRoomNotFoundException(id));

        String status = body.get("status");
        if (!status.equals("APPROVED") && !status.equals("REJECTED")) {
            return ResponseEntity.badRequest().body(Map.of("message", "Invalid status"));
        }

        booking.setStatus(status);
        bookingRepository.save(booking);

        Room room = booking.getRoom();
        room.setAvailable(!status.equals("APPROVED")); // if approved, not available
        roomRepository.save(room);

        return ResponseEntity.ok(booking);
    }
}
