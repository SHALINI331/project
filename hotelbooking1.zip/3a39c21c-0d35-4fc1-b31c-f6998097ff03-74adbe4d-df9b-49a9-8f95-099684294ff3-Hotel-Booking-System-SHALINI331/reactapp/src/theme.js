import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#3b82f6'
    },
    secondary: {
      main: '#60a5fa'
    },
    background: {
      default: '#000000',
      paper: '#0f172a'
    },
    text: {
      primary: '#ffffff',
      secondary: '#94a3b8'
    }
  },
  shape: { borderRadius: 12 },
  typography: {
    fontFamily: 'Inter, Segoe UI, Arial, sans-serif'
  }
});

export default theme;


