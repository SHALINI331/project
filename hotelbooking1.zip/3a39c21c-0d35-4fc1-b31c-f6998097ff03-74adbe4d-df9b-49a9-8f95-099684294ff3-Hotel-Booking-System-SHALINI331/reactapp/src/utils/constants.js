// constants.js - Shared constants for the hotel room booking system

export const ROOM_TYPES = ['Standard', 'Deluxe', 'Suite'];
export const BOOKING_STATUSES = ['PENDING', 'APPROVED', 'REJECTED'];
export const API_BASE_URL = 'https://8080-feebdeabdbfcdbbbeadbeddfbafff.premiumproject.examly.io/api';
