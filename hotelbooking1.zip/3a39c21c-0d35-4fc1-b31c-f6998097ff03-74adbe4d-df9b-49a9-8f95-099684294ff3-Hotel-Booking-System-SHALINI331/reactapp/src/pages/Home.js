import React from 'react';
import { Link } from 'react-router-dom';
import {
  Box,
  Button,
  Container,
  Stack,
  Typography,
  Card,
  CardContent,
  Grid,
  Chip
} from '@mui/material';
import {
  Person,
  AdminPanelSettings,
  Hotel,
  Security,
  Explore
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

export default function Home() {
  const { currentUser } = useAuth();

  return (
    <Box>
      <Box sx={{
        position: 'relative',
        borderRadius: 2,
        overflow: 'hidden',
        minHeight: 600,
        display: 'grid',
        placeItems: 'center',
        mb: 4
      }}>
        <Box sx={{
          position: 'absolute',
          inset: 0,
          backgroundImage: 'url(https://images.unsplash.com/photo-1571896349842-33c89424de2d?q=80&w=1600&auto=format&fit=crop)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }} />
        <Box sx={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(120deg, rgba(0,0,0,0.7), rgba(59,130,246,0.3))'
        }} />
        <Container sx={{ position: 'relative', textAlign: 'center' }}>
          <Typography variant="h3" sx={{ fontWeight: 800, color: 'white' }}>
            Find your perfect stay
          </Typography>
          <Typography sx={{ opacity: 0.9, mt: 1.5, color: 'white' }}>
            Book handpicked rooms with flexible plans and premium comfort.
          </Typography>

          {!currentUser ? (
            <Stack direction="row" spacing={2} justifyContent="center" sx={{ mt: 3 }}>
              <Button component={Link} to="/rooms" variant="contained" size="large">
                <Explore sx={{ mr: 1 }} />
                Explore Rooms
              </Button>
              <Button component={Link} to="/register" variant="outlined" size="large" sx={{ color: 'white', borderColor: 'white' }}>
                <Person sx={{ mr: 1 }} />
                Join as Guest
              </Button>
            </Stack>
          ) : (
            <Stack direction="row" spacing={2} justifyContent="center" sx={{ mt: 3 }}>
              <Button
                component={Link}
                to={currentUser.role === "ADMIN" ? "/admin" : "/dashboard"}
                variant="contained"
                size="large"
                color={currentUser.role === "ADMIN" ? "error" : "primary"}
              >
                {currentUser.role === "ADMIN" ? <AdminPanelSettings sx={{ mr: 1 }} /> : <Person sx={{ mr: 1 }} />}
                {currentUser.role === "ADMIN" ? "Admin Panel" : "My Dashboard"}
              </Button>
              <Button component={Link} to="/rooms" variant="outlined" size="large" sx={{ color: 'white', borderColor: 'white' }}>
                <Hotel sx={{ mr: 1 }} />
                Browse Rooms
              </Button>
            </Stack>
          )}
        </Container>
      </Box>

      {/* Role-based registration section
      {!currentUser && (
        <Container sx={{ py: 4 }}>
          <Typography variant="h4" sx={{ textAlign: 'center', mb: 4, fontWeight: 700 }}>
            Choose Your Account Type
          </Typography>

          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <Card sx={{
                height: '100%',
                transition: 'transform 0.2s',
                '&:hover': { transform: 'translateY(-4px)' }
              }}>
                <CardContent sx={{ textAlign: 'center', p: 4 }}>
                  <Person sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
                  <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
                    Guest Account
                  </Typography>
                  <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
                    Perfect for travelers who want to book rooms and manage their reservations.
                  </Typography>
                  <Stack spacing={2}>
                    <Chip label="Book Rooms" color="primary" variant="outlined" />
                    <Chip label="View Bookings" color="primary" variant="outlined" />
                    <Chip label="Manage Profile" color="primary" variant="outlined" />
                  </Stack>
                  <Button
                    component={Link}
                    to="/register"
                    variant="contained"
                    fullWidth
                    sx={{ mt: 3 }}
                  >
                    Register as Guest
                  </Button>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={6}>
              <Card sx={{
                height: '100%',
                transition: 'transform 0.2s',
                '&:hover': { transform: 'translateY(-4px)' }
              }}>
                <CardContent sx={{ textAlign: 'center', p: 4 }}>
                  <AdminPanelSettings sx={{ fontSize: 60, color: 'error.main', mb: 2 }} />
                  <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
                    Administrator Account
                  </Typography>
                  <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
                    For hotel staff to manage rooms, bookings, and oversee operations.
                  </Typography>
                  <Stack spacing={2}>
                    <Chip label="Manage Rooms" color="error" variant="outlined" />
                    <Chip label="Handle Bookings" color="error" variant="outlined" />
                    <Chip label="Admin Dashboard" color="error" variant="outlined" />
                  </Stack>
                  <Button
                    component={Link}
                    to="/admin-register"
                    variant="contained"
                    color="error"
                    fullWidth
                    sx={{ mt: 3 }}
                  >
                    Register as Admin
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Container>
      )} */}
    </Box>
  );
}


