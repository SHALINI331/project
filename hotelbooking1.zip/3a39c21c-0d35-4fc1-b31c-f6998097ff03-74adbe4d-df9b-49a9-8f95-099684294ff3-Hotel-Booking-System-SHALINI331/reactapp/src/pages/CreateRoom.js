import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, TextField, Box, Paper, Typography } from '@mui/material';
import { API_BASE_URL } from '../utils/constants';

export default function CreateRoomPage() {
    const navigate = useNavigate();

    const [form, setForm] = useState({
        roomNumber: '',
        roomType: '',
        price: '',
        capacity: '',
        available: true
    });

    const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            // const res = await fetch(`${API_BASE_URL}/rooms`, {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(form)
            // });

            const res = await fetch(`${API_BASE_URL}/rooms`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(form)
            });

            if (!res.ok) throw new Error('Failed to create room');

            navigate('/admin'); // go back to admin dashboard
        } catch (err) {
            console.error(err);
            alert('Failed to create room.');
        }
    };

    return (
        <Box sx={{ maxWidth: 500, mx: 'auto', mt: 5 }}>
            <Paper sx={{ p: 3, borderRadius: 2 }}>
                <Typography variant="h5" sx={{ mb: 3 }}>Create Room</Typography>

                <form onSubmit={handleSubmit}>
                    <TextField
                        label="Room Number"
                        name="roomNumber"
                        value={form.roomNumber}
                        onChange={handleChange}
                        fullWidth
                        required
                        margin="normal"
                    />
                    <TextField
                        label="Room Type"
                        name="roomType"
                        value={form.roomType}
                        onChange={handleChange}
                        fullWidth
                        required
                        margin="normal"
                    />
                    <TextField
                        label="Price"
                        name="price"
                        type="number"
                        value={form.price}
                        onChange={handleChange}
                        fullWidth
                        required
                        margin="normal"
                    />
                    <TextField
                        label="Capacity"
                        name="capacity"
                        type="number"
                        value={form.capacity}
                        onChange={handleChange}
                        fullWidth
                        required
                        margin="normal"
                    />

                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
                        <Button variant="outlined" onClick={() => navigate('/admin')}>
                            Back
                        </Button>
                        <Button variant="contained" color="primary" type="submit">
                            Save Room
                        </Button>
                    </Box>
                </form>
            </Paper>
        </Box>
    );
}
