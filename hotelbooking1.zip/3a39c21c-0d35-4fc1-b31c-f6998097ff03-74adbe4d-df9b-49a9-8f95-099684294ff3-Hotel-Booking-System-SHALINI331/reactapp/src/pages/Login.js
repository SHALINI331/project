
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Box,
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  Alert,
  Divider,
  ToggleButtonGroup,
  ToggleButton,
  Fade,
  Zoom,
  InputAdornment,
  IconButton,
  Tooltip,
  CircularProgress,
  Snackbar,
  Slide
} from '@mui/material';
import {
  Login as LoginIcon,
  Person,
  AdminPanelSettings,
  Visibility,
  VisibilityOff,
  Email,
  Lock,
  Hotel,
  CheckCircle,
  Error
} from '@mui/icons-material';
import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [userType, setUserType] = useState('USER');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [showSuccess, setShowSuccess] = useState(false);

  // Clear errors when user type changes
  useEffect(() => {
    setError('');
    setFormErrors({});
  }, [userType]);

  const validateForm = () => {
    const errors = {};

    if (!email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errors.email = 'Please enter a valid email address';
    }

    if (!password) {
      errors.password = 'Password is required';
    } else if (password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Attempt login with a specific role
  const attemptLogin = async (roleToUse) => {
    const res = await axios.post(`${API_BASE_URL}/users/login`, {
      email: email.trim(),
      password,
      role: roleToUse
    });
    return res.data;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setError('');
    setLoading(true);

    try {
      console.log('Attempting login with:', { email, password, role: userType });

      let data;
      try {
        data = await attemptLogin(userType);
      } catch (err) {
        // If unauthorized, retry with the opposite role automatically
        if (err?.response?.status === 401) {
          const fallbackRole = userType === 'ADMIN' ? 'USER' : 'ADMIN';
          try {
            data = await attemptLogin(fallbackRole);
            // Switch UI toggle to reflect the actual role
            setUserType(fallbackRole);
          } catch (fallbackErr) {
            throw fallbackErr;
          }
        } else {
          throw err;
        }
      }

      // Store user data in localStorage and update AuthContext
      localStorage.setItem("user", JSON.stringify(data));

      // Update auth context before showing success
      await login(email, password, data.role);

      // Show success message before navigation
      setShowSuccess(true);

      // Navigate based on the user role from the response
      setTimeout(() => {
        navigate(data.role === "ADMIN" ? "/admin" : "/dashboard");
      }, 1000);

    } catch (err) {
      console.error('Login error:', err);
      const serverMessage = typeof err?.response?.data === 'string' ? err.response.data : err.response?.data?.message;
      const errorMessage = serverMessage || "Login failed. Please check your email, password, and role.";
      setError(errorMessage);

      // Clear password on error
      setPassword('');
    } finally {
      setLoading(false);
    }
  };

  const handleUserTypeChange = (event, newUserType) => {
    if (newUserType !== null) {
      setUserType(newUserType);
    }
  };

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleInputChange = (field, value) => {
    if (formErrors[field]) {
      setFormErrors(prev => ({ ...prev, [field]: '' }));
    }
    if (field === 'email') setEmail(value);
    if (field === 'password') setPassword(value);
  };

  const handleCloseSuccess = () => {
    setShowSuccess(false);
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)',
        display: 'flex',
        alignItems: 'center',
        py: 4,
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      {/* Background decorative elements */}
      <Box
        sx={{
          position: 'absolute',
          top: -50,
          right: -50,
          width: 200,
          height: 200,
          borderRadius: '50%',
          background: 'linear-gradient(45deg, rgba(59,130,246,0.1), rgba(139,92,246,0.1))',
          animation: 'float 6s ease-in-out infinite',
          backdropFilter: 'blur(20px)'
        }}
      />
      <Box
        sx={{
          position: 'absolute',
          bottom: -30,
          left: -30,
          width: 150,
          height: 150,
          borderRadius: '50%',
          background: 'linear-gradient(45deg, rgba(236,72,153,0.1), rgba(59,130,246,0.1))',
          animation: 'float 8s ease-in-out infinite reverse',
          backdropFilter: 'blur(20px)'
        }}
      />

      <Container maxWidth="xs" sx={{ px: { xs: 2, sm: 3 } }}>
        <Fade in timeout={800}>
          <Paper
            sx={{
              p: { xs: 2.5, sm: 3.5 },
              borderRadius: 3,
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
              background: 'rgba(30, 41, 59, 0.95)',
              backdropFilter: 'blur(16px)',
              border: '1px solid rgba(100, 116, 139, 0.2)',
              position: 'relative',
              overflow: 'hidden',
              maxWidth: '420px',
              mx: 'auto'
            }}
          >
            {/* Success overlay */}
            {showSuccess && (
              <Box
                sx={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.95), rgba(16, 185, 129, 0.95))',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  zIndex: 10,
                  borderRadius: 3
                }}
              >
                <Box sx={{ textAlign: 'center', color: 'white' }}>
                  <CheckCircle sx={{ fontSize: 50, mb: 1.5 }} />
                  <Typography variant="h5" sx={{ fontWeight: 600, mb: 1, fontSize: '1.4rem' }}>
                    Login Successful!
                  </Typography>
                  <Typography variant="body1" sx={{ fontSize: '0.95rem' }}>
                    Redirecting to dashboard...
                  </Typography>
                </Box>
              </Box>
            )}

            <Zoom in timeout={1000}>
              <Box sx={{ textAlign: 'center', mb: 3 }}>
                <Box
                  sx={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: 64,
                    height: 64,
                    borderRadius: '50%',
                    background: userType === 'ADMIN'
                      ? 'linear-gradient(45deg, #dc2626, #ef4444)'
                      : 'linear-gradient(45deg, #3b82f6, #60a5fa)',
                    mb: 2.5,
                    boxShadow: userType === 'ADMIN'
                      ? '0 8px 32px rgba(220, 38, 38, 0.4)'
                      : '0 8px 32px rgba(59, 130, 246, 0.4)',
                    transition: 'all 0.3s ease'
                  }}
                >
                  <Hotel sx={{ fontSize: 32, color: 'white' }} />
                </Box>
                <Typography
                  variant="h4"
                  sx={{
                    fontWeight: 800,
                    mb: 0.5,
                    background: 'linear-gradient(45deg, #f8fafc, #e2e8f0)',
                    backgroundClip: 'text',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    fontSize: { xs: '1.8rem', sm: '2rem' }
                  }}
                >
                  Welcome Back
                </Typography>
                <Typography variant="body2" sx={{ color: '#94a3b8', fontSize: '0.95rem' }}>
                  Sign in to your account to continue
                </Typography>
              </Box>
            </Zoom>

            <form onSubmit={handleSubmit}>
              <Box sx={{ mb: 3 }}>
                <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 600, color: '#f1f5f9' }}>
                  Login As
                </Typography>
                <ToggleButtonGroup
                  value={userType}
                  exclusive
                  onChange={handleUserTypeChange}
                  fullWidth
                  sx={{
                    mb: 2.5,
                    '& .MuiToggleButton-root': {
                      border: '1px solid #475569',
                      borderRadius: '10px !important',
                      margin: '0 3px',
                      backgroundColor: '#334155',
                      color: '#cbd5e1',
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        backgroundColor: '#475569',
                        transform: 'translateY(-1px)',
                        boxShadow: '0 4px 12px rgba(0,0,0,0.25)'
                      }
                    }
                  }}
                >
                  <ToggleButton
                    value="USER"
                    sx={{
                      py: 1.5,
                      textTransform: 'none',
                      fontWeight: 600,
                      fontSize: '0.9rem',
                      '&.Mui-selected': {
                        backgroundColor: '#3b82f6',
                        color: 'white',
                        border: '1px solid #3b82f6',
                        '&:hover': {
                          backgroundColor: '#2563eb'
                        }
                      }
                    }}
                  >
                    <Person sx={{ mr: 1, fontSize: '1.1rem' }} />
                    User
                  </ToggleButton>
                  <ToggleButton
                    value="ADMIN"
                    sx={{
                      py: 1.5,
                      textTransform: 'none',
                      fontWeight: 600,
                      fontSize: '0.9rem',
                      '&.Mui-selected': {
                        backgroundColor: '#dc2626',
                        color: 'white',
                        border: '1px solid #dc2626',
                        '&:hover': {
                          backgroundColor: '#b91c1c'
                        }
                      }
                    }}
                  >
                    <AdminPanelSettings sx={{ mr: 1, fontSize: '1.1rem' }} />
                    Admin
                  </ToggleButton>
                </ToggleButtonGroup>
              </Box>

              <TextField
                fullWidth
                label="Email Address"
                type="email"
                value={email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="you@email.com"
                required
                variant="outlined"
                error={!!formErrors.email}
                helperText={formErrors.email}
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Email sx={{ color: formErrors.email ? '#ef4444' : '#94a3b8', fontSize: '1.1rem' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 2.5,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '10px',
                    backgroundColor: '#334155',
                    '& fieldset': {
                      borderColor: '#475569'
                    },
                    '&:hover fieldset': {
                      borderColor: formErrors.email ? '#ef4444' : '#3b82f6'
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: formErrors.email ? '#ef4444' : '#3b82f6',
                      borderWidth: '2px'
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: '#94a3b8',
                    '&.Mui-focused': {
                      color: formErrors.email ? '#ef4444' : '#3b82f6'
                    }
                  },
                  '& .MuiOutlinedInput-input': {
                    color: '#f8fafc',
                    '&::placeholder': {
                      color: '#64748b'
                    }
                  },
                  '& .MuiFormHelperText-root': {
                    color: '#ef4444'
                  }
                }}
              />

              <TextField
                fullWidth
                label="Password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                placeholder="••••••••"
                required
                variant="outlined"
                error={!!formErrors.password}
                helperText={formErrors.password}
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Lock sx={{ color: formErrors.password ? '#ef4444' : '#94a3b8', fontSize: '1.1rem' }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <Tooltip title={showPassword ? "Hide password" : "Show password"}>
                        <IconButton
                          onClick={handleTogglePasswordVisibility}
                          edge="end"
                          size="small"
                          sx={{ color: '#94a3b8' }}
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </Tooltip>
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 2.5,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '10px',
                    backgroundColor: '#334155',
                    '& fieldset': {
                      borderColor: '#475569'
                    },
                    '&:hover fieldset': {
                      borderColor: formErrors.password ? '#ef4444' : '#3b82f6'
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: formErrors.password ? '#ef4444' : '#3b82f6',
                      borderWidth: '2px'
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: '#94a3b8',
                    '&.Mui-focused': {
                      color: formErrors.password ? '#ef4444' : '#3b82f6'
                    }
                  },
                  '& .MuiOutlinedInput-input': {
                    color: '#f8fafc',
                    '&::placeholder': {
                      color: '#64748b'
                    }
                  },
                  '& .MuiFormHelperText-root': {
                    color: '#ef4444'
                  }
                }}
              />

              {error && (
                <Fade in timeout={300}>
                  <Alert
                    severity="error"
                    icon={<Error />}
                    sx={{
                      mb: 2.5,
                      borderRadius: '10px',
                      backgroundColor: 'rgba(239, 68, 68, 0.1)',
                      border: '1px solid rgba(239, 68, 68, 0.3)',
                      color: '#fecaca',
                      '& .MuiAlert-icon': {
                        color: '#ef4444',
                        fontSize: '1.25rem'
                      }
                    }}
                  >
                    {error}
                  </Alert>
                </Fade>
              )}

              <Button
                type="submit"
                variant="contained"
                fullWidth
                size="medium"
                startIcon={loading ? <CircularProgress size={18} color="inherit" /> : <LoginIcon />}
                disabled={loading}
                sx={{
                  borderRadius: '20px',
                  textTransform: 'none',
                  fontWeight: 700,
                  fontSize: '1rem',
                  py: 1.5,
                  mb: 2.5,
                  background: userType === 'ADMIN'
                    ? 'linear-gradient(45deg, #dc2626, #ef4444)'
                    : 'linear-gradient(45deg, #3b82f6, #60a5fa)',
                  boxShadow: userType === 'ADMIN'
                    ? '0 8px 25px rgba(220, 38, 38, 0.4)'
                    : '0 8px 25px rgba(59, 130, 246, 0.4)',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    background: userType === 'ADMIN'
                      ? 'linear-gradient(45deg, #b91c1c, #dc2626)'
                      : 'linear-gradient(45deg, #2563eb, #3b82f6)',
                    transform: 'translateY(-2px)',
                    boxShadow: userType === 'ADMIN'
                      ? '0 12px 30px rgba(220, 38, 38, 0.5)'
                      : '0 12px 30px rgba(59, 130, 246, 0.5)'
                  },
                  '&:disabled': {
                    background: '#475569',
                    transform: 'none',
                    boxShadow: 'none'
                  }
                }}
              >
                {loading ? "Signing In..." : "Sign In"}
              </Button>
            </form>

            <Divider sx={{ my: 2.5, borderColor: '#475569' }}>
              <Typography variant="body2" sx={{ px: 2, fontWeight: 600, color: '#94a3b8', fontSize: '0.85rem' }}>
                OR
              </Typography>
            </Divider>

            <Box sx={{ textAlign: 'center' }}>
              <Typography variant="body2" sx={{ mb: 2, color: '#94a3b8', fontSize: '0.9rem' }}>
                Don't have an account?
              </Typography>
              <Button
                component={Link}
                to="/register"
                variant="outlined"
                size="medium"
                fullWidth
                sx={{
                  borderRadius: '20px',
                  textTransform: 'none',
                  fontWeight: 600,
                  py: 1.25,
                  mb: 1.5,
                  borderColor: '#3b82f6',
                  color: '#60a5fa',
                  borderWidth: '1.5px',
                  backgroundColor: 'transparent',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    transform: 'translateY(-1px)',
                    color: '#3b82f6'
                  }
                }}
              >
                Create Regular Account
              </Button>

              <Button
                component={Link}
                to="/admin-register"
                variant="text"
                size="small"
                startIcon={<AdminPanelSettings />}
                sx={{
                  textTransform: 'none',
                  fontWeight: 600,
                  color: '#f87171',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    backgroundColor: 'rgba(220, 38, 38, 0.1)',
                    transform: 'translateY(-1px)',
                    color: '#ef4444'
                  }
                }}
              >
                Create Admin Account
              </Button>
            </Box>
          </Paper>
        </Fade>
      </Container>

      {/* Success Snackbar */}
      <Snackbar
        open={showSuccess}
        autoHideDuration={2000}
        onClose={handleCloseSuccess}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        TransitionComponent={Slide}
      >
        <Alert
          onClose={handleCloseSuccess}
          severity="success"
          sx={{
            width: '100%',
            backgroundColor: '#065f46',
            color: '#d1fae5'
          }}
        >
          Login successful! Redirecting...
        </Alert>
      </Snackbar>

      <style jsx>{`
     @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-20px); }                                                                                                                                    }
    `}</style>
    </Box>
  );
}

