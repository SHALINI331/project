import React, { useEffect, useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { getRoomById } from '../utils/api';
import BookingForm from '../components/BookingForm';
import { useAuth } from '../context/AuthContext';
import { Box, Typography, Container, Paper, Chip, Divider, Button } from '@mui/material';

export default function RoomDetails() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [room, setRoom] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    // Check if room data was passed via navigation state
    if (location.state && location.state.roomId) {
      setRoom(location.state);
      setLoading(false);
    } else {
      // Fallback to API call if no state data
      getRoomById(id)
        .then(setRoom)
        .catch(() => setError('Could not load room'))
        .finally(() => setLoading(false));
    }
  }, [id, location.state]);

  if (loading) return <div className="loading">Loading room...</div>;
  if (error) return <div className="error">{error}</div>;
  if (!room) return <div className="error">Room not found</div>;

  return (
    <Container maxWidth="md" sx={{ py: 5 }}>
      <Paper sx={{ p: 4, borderRadius: 3, boxShadow: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 2, textAlign: 'center' }}>
          Room #{room.roomNumber}
        </Typography>

        <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
          <Chip
            label={room.available ? 'Available' : 'Booked'}
            color={room.available ? 'success' : 'error'}
            sx={{ fontWeight: 600 }}
          />
        </Box>

        <Typography variant="h6" sx={{ mb: 1, textAlign: 'center', color: 'primary.main' }}>
          {room.roomType} • Capacity {room.capacity} people
        </Typography>

        {room.description && (
          <Typography
            variant="body1"
            color="text.secondary"
            sx={{ mb: 2, textAlign: 'center' }}
          >
            {room.description}
          </Typography>
        )}

        <Typography
          variant="h5"
          sx={{
            fontWeight: 700,
            color: 'primary.main',
            textAlign: 'center',
            mb: 3
          }}
        >
          ₹{room.price} / night
        </Typography>

        <Divider sx={{ mb: 3 }} />

        {/* Show different content based on user authentication and role */}
        {!currentUser ? (
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="body1" sx={{ mb: 2, color: 'text.secondary' }}>
              Please sign in to book this room.
            </Typography>
            <Button
              variant="contained"
              size="large"
              onClick={() => navigate('/login')}
              sx={{
                borderRadius: '25px',
                textTransform: 'none',
                fontWeight: 600,
                px: 4,
                py: 1.5,
                background: 'linear-gradient(45deg, #3b82f6, #60a5fa)',
                '&:hover': {
                  background: 'linear-gradient(45deg, #2563eb, #3b82f6)'
                }
              }}
            >
              Sign In to Book
            </Button>
          </Box>
        ) : currentUser.role === 'ADMIN' ? (
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="body1" sx={{ mb: 2, color: 'text.secondary' }}>
              Admin users cannot book rooms. Use the admin dashboard to manage rooms and bookings.
            </Typography>
            <Button
              variant="contained"
              size="large"
              onClick={() => navigate('/admin')}
              sx={{
                borderRadius: '25px',
                textTransform: 'none',
                fontWeight: 600,
                px: 4,
                py: 1.5,
                background: 'linear-gradient(45deg, #10b981, #34d399)',
                '&:hover': {
                  background: 'linear-gradient(45deg, #059669, #10b981)'
                }
              }}
            >
              Go to Admin Dashboard
            </Button>
          </Box>
        ) : (
          <BookingForm room={room} />
        )}
      </Paper>
    </Container>
  );
}
