import React from 'react';
import { Box, Container, Typography, Paper, Grid, Card, CardContent } from '@mui/material';
import { Hotel, Star, Security, Support, LocationOn, AccessTime, Payment, VerifiedUser } from '@mui/icons-material';

export default function About() {
  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h2" sx={{ fontWeight: 700, mb: 3, background: 'linear-gradient(45deg, #3b82f6, #60a5fa)', backgroundClip: 'text', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          About StayEase
        </Typography>
        <Typography variant="h6" color="text.secondary" sx={{ maxWidth: 800, mx: 'auto', lineHeight: 1.6, mb: 4 }}>
          StayEase is a modern hotel room booking experience built to help travelers quickly find and reserve great rooms.
          We focus on simplicity, fairness in pricing, and delightful design.
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 600, mx: 'auto' }}>
          Founded in 2024, we've been connecting travelers with exceptional accommodations worldwide, 
          providing a seamless booking experience with transparent pricing and outstanding customer service.
        </Typography>
      </Box>

      <Grid container spacing={4} sx={{ mb: 6 }}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 4, height: '100%', borderRadius: 3, boxShadow: 3 }}>
            <Typography variant="h5" sx={{ fontWeight: 700, mb: 3, color: 'primary.main' }}>
              Our Mission
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ lineHeight: 1.7, mb: 3 }}>
              To provide travelers with a seamless, transparent, and enjoyable hotel booking experience. 
              We believe that finding the perfect accommodation should be effortless and stress-free.
            </Typography>
            <Typography variant="body2" color="text.secondary">
              We strive to eliminate the complexity of travel planning by offering a user-friendly platform 
              that puts the power of choice in your hands.
            </Typography>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 4, height: '100%', borderRadius: 3, boxShadow: 3 }}>
            <Typography variant="h5" sx={{ fontWeight: 700, mb: 3, color: 'primary.main' }}>
              Our Vision
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ lineHeight: 1.7, mb: 3 }}>
              To become the most trusted and user-friendly hotel booking platform, connecting travelers 
              with exceptional accommodations worldwide through innovative technology and outstanding service.
            </Typography>
            <Typography variant="body2" color="text.secondary">
              We envision a world where booking the perfect stay is as simple as a few clicks, 
              with every detail taken care of for your peace of mind.
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
          Why Choose StayEase?
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 600, mx: 'auto' }}>
          We're committed to providing you with the best booking experience possible
        </Typography>
      </Box>

      <Grid container spacing={4} sx={{ mb: 6 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%', textAlign: 'center', p: 3, borderRadius: 3, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
            <CardContent>
              <Hotel sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Premium Rooms
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Carefully curated selection of high-quality accommodations with modern amenities
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%', textAlign: 'center', p: 3, borderRadius: 3, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
            <CardContent>
              <Star sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Best Prices
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Competitive rates with no hidden fees, taxes, or booking charges
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%', textAlign: 'center', p: 3, borderRadius: 3, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
            <CardContent>
              <Security sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Secure Booking
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Safe and secure payment processing with SSL encryption for your peace of mind
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%', textAlign: 'center', p: 3, borderRadius: 3, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
            <CardContent>
              <Support sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                24/7 Support
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Round-the-clock customer support to assist you anytime, anywhere
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Grid container spacing={4}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%', textAlign: 'center', p: 3, borderRadius: 3, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
            <CardContent>
              <LocationOn sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Prime Locations
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Hotels in the best locations with easy access to attractions and transport
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%', textAlign: 'center', p: 3, borderRadius: 3, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
            <CardContent>
              <AccessTime sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Instant Booking
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Book your room instantly with immediate confirmation and no waiting
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%', textAlign: 'center', p: 3, borderRadius: 3, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
            <CardContent>
              <Payment sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Flexible Payment
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Multiple payment options including credit cards, digital wallets, and more
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%', textAlign: 'center', p: 3, borderRadius: 3, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
            <CardContent>
              <VerifiedUser sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Verified Hotels
              </Typography>
              <Typography variant="body2" color="text.secondary">
                All hotels are verified and quality-checked for your safety and comfort
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}


