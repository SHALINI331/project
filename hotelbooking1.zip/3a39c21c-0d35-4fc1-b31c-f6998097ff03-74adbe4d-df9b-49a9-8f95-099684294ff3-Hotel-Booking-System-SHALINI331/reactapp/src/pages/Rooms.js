import React from 'react';
import RoomListing from '../components/RoomListing';

export default function Rooms() {
  return (
    <div>
      <h2 style={{ color: '#3730a3', marginBottom: 16 }}>Available Rooms</h2>
      <RoomListing />
    </div>
  );
}

