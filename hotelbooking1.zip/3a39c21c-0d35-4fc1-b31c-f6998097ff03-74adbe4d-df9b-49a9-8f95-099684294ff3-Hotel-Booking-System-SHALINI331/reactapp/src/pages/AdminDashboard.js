import React, { useEffect, useState } from 'react';
import { API_BASE_URL } from '../utils/constants';
import { Box, Typography, Button, Paper, Grid, Divider, CircularProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';

export default function AdminPanel() {
  const [rooms, setRooms] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    setLoading(true);
    Promise.all([
      fetch(`${API_BASE_URL}/rooms`)
        .then(res => res.json()),
      fetch(`${API_BASE_URL}/bookings`)
        .then(res => res.json())
    ])
      .then(([roomsData, bookingsData]) => {
        setRooms(roomsData);
        setBookings(bookingsData);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  const handleDeleteRoom = (roomId) => {
    fetch(`${API_BASE_URL}/rooms/${roomId}`, { method: 'DELETE' })
      .then(res => {
        if (!res.ok) throw new Error(`Failed to delete room: ${res.status}`);
        setRooms(prevRooms => prevRooms.filter(r => r.roomId !== roomId));
      })
      .catch(err => {
        console.error(err);
        alert('Room deletion failed. Check the server.');
      });
  };

  const handleUpdateBooking = (bookingId, status) => {
    fetch(`${API_BASE_URL}/bookings/${bookingId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    })
      .then(res => res.json())
      .then(updatedBooking => {
        setBookings(bookings.map(b => b.bookingId === updatedBooking.bookingId ? updatedBooking : b));
      })
      .catch(err => console.error(err));
  };

  if (loading) return (
    <Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
      <CircularProgress />
    </Box>
  );

  return (
    <Box sx={{ p: 3 }}>
      {/* Room Management Header with Create Button */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h5" sx={{ color: '#3730a3' }}>Room Management</Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={() => navigate('/create-room')}
        >
          + Create Room
        </Button>
      </Box>

      <Grid container spacing={2}>
        {rooms.map(room => (
          <Grid item xs={12} sm={6} md={4} key={room.roomId}>
            <Paper sx={{ p: 2, borderRadius: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="subtitle1" fontWeight={600}>{room.roomType}</Typography>
                <Typography variant="body2">${room.price} / night</Typography>
              </Box>
              <Button
                variant="outlined"
                color="error"
                onClick={() => handleDeleteRoom(room.roomId)}
                size="small"
              >
                Delete
              </Button>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Divider sx={{ my: 4 }} />

      <Typography variant="h5" sx={{ color: '#3730a3', mb: 2 }}>All Bookings</Typography>
      <Grid container spacing={2}>
        {bookings.map(b => (
          <Grid item xs={12} md={10} key={b.bookingId}>
            <Paper sx={{ p: 2, borderRadius: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="subtitle1" fontWeight={600}>
                  Booking #{b.bookingId} — Room {b.room.roomType}
                </Typography>
                <Typography variant="body2">
                  Guest: {b.guestName} ({b.guestEmail}) | {b.checkInDate} → {b.checkOutDate} | ₹{b.totalPrice}
                </Typography>
                <Typography variant="body2">Status: {b.status}</Typography>
              </Box>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button
                  variant="contained"
                  color="success"
                  size="small"
                  disabled={b.status === 'APPROVED'}
                  onClick={() => handleUpdateBooking(b.bookingId, 'APPROVED')}
                >
                  Approve
                </Button>
                <Button
                  variant="outlined"
                  color="error"
                  size="small"
                  onClick={() => handleUpdateBooking(b.bookingId, 'REJECTED')}
                >
                  Reject
                </Button>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
