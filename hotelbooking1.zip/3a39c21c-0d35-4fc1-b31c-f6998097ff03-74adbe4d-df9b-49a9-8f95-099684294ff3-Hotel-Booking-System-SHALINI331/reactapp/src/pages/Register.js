import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import {
  Box,
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  Alert,
  Divider,
  CircularProgress,
  Fade,
  Zoom,
  InputAdornment,
  IconButton,
  Tooltip,
  Snackbar,
  Slide,
  LinearProgress
} from '@mui/material';
import {
  PersonAdd,
  AdminPanelSettings,
  ArrowBack,
  Visibility,
  VisibilityOff,
  Email,
  Lock,
  Person,
  Hotel,
  CheckCircle,
  Error
} from '@mui/icons-material';
import axios from "axios";
import { API_BASE_URL } from '../utils/constants';

export default function Register() {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [showSuccess, setShowSuccess] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);

  // Clear errors when inputs change
  useEffect(() => {
    if (formErrors.name && name) setFormErrors(prev => ({ ...prev, name: '' }));
    if (formErrors.email && email) setFormErrors(prev => ({ ...prev, email: '' }));
    if (formErrors.password && password) setFormErrors(prev => ({ ...prev, password: '' }));
    if (formErrors.confirmPassword && confirmPassword) setFormErrors(prev => ({ ...prev, confirmPassword: '' }));
  }, [name, email, password, confirmPassword, formErrors]);

  // Calculate password strength
  useEffect(() => {
    if (!password) {
      setPasswordStrength(0);
      return;
    }

    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (/[a-z]/.test(password)) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[0-9]/.test(password)) strength += 25;

    setPasswordStrength(strength);
  }, [password]);

  const getPasswordStrengthColor = () => {
    if (passwordStrength <= 25) return 'error';
    if (passwordStrength <= 50) return 'warning';
    if (passwordStrength <= 75) return 'info';
    return 'success';
  };

  const getPasswordStrengthText = () => {
    if (passwordStrength <= 25) return 'Weak';
    if (passwordStrength <= 50) return 'Fair';
    if (passwordStrength <= 75) return 'Good';
    return 'Strong';
  };

  const validateForm = () => {
    const errors = {};

    if (!name.trim()) {
      errors.name = 'Full name is required';
    } else if (name.trim().length < 2) {
      errors.name = 'Name must be at least 2 characters';
    }

    if (!email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errors.email = 'Please enter a valid email address';
    }

    if (!password) {
      errors.password = 'Password is required';
    } else if (password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    }

    if (!confirmPassword) {
      errors.confirmPassword = 'Please confirm your password';
    } else if (password !== confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setError("");
    setMessage("");
    setLoading(true);

    try {
      const res = await axios.post(`${API_BASE_URL}/users/register`, {
        name: name.trim(),
        email: email.trim(),
        password,
        role: "USER", // default role when registering
      });

      if (res.status === 200 || res.status === 201) {
        setShowSuccess(true);
        setMessage("✅ Registration successful. Redirecting to login...");
        setTimeout(() => navigate("/login"), 2000);
      } else {
        setError("❌ Registration failed. Try again.");
      }
    } catch (err) {
      const errorMessage = err.response?.data?.message || "⚠️ Something went wrong. Please try again.";
      setError(errorMessage);

      // Clear sensitive fields on error
      setPassword('');
      setConfirmPassword('');
    } finally {
      setLoading(false);
    }
  };

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleToggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  const handleInputChange = (field, value) => {
    if (field === 'name') setName(value);
    if (field === 'email') setEmail(value);
    if (field === 'password') setPassword(value);
    if (field === 'confirmPassword') setConfirmPassword(value);
  };

  const handleCloseSuccess = () => {
    setShowSuccess(false);
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)',
        display: 'flex',
        alignItems: 'center',
        py: 4,
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      {/* Background decorative elements */}
      <Box
        sx={{
          position: 'absolute',
          top: -50,
          right: -50,
          width: 200,
          height: 200,
          borderRadius: '50%',
          background: 'linear-gradient(45deg, rgba(59,130,246,0.1), rgba(139,92,246,0.1))',
          animation: 'float 6s ease-in-out infinite',
          backdropFilter: 'blur(20px)'
        }}
      />
      <Box
        sx={{
          position: 'absolute',
          bottom: -30,
          left: -30,
          width: 150,
          height: 150,
          borderRadius: '50%',
          background: 'linear-gradient(45deg, rgba(236,72,153,0.1), rgba(59,130,246,0.1))',
          animation: 'float 8s ease-in-out infinite reverse',
          backdropFilter: 'blur(20px)'
        }}
      />

      <Container maxWidth="xs" sx={{ px: { xs: 2, sm: 3 } }}>
        <Fade in timeout={800}>
          <Paper
            sx={{
              p: { xs: 2.5, sm: 3.5 },
              borderRadius: 3,
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
              background: 'rgba(30, 41, 59, 0.95)',
              backdropFilter: 'blur(16px)',
              border: '1px solid rgba(100, 116, 139, 0.2)',
              position: 'relative',
              overflow: 'hidden',
              maxWidth: '420px',
              mx: 'auto'
            }}
          >
            {/* Success overlay */}
            {showSuccess && (
              <Box
                sx={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.95), rgba(16, 185, 129, 0.95))',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  zIndex: 10,
                  borderRadius: 3
                }}
              >
                <Box sx={{ textAlign: 'center', color: 'white' }}>
                  <CheckCircle sx={{ fontSize: 50, mb: 1.5 }} />
                  <Typography variant="h5" sx={{ fontWeight: 600, mb: 1, fontSize: '1.4rem' }}>
                    Registration Successful!
                  </Typography>
                  <Typography variant="body1" sx={{ fontSize: '0.95rem' }}>
                    Redirecting to login...
                  </Typography>
                </Box>
              </Box>
            )}

            <Zoom in timeout={1000}>
              <Box sx={{ textAlign: 'center', mb: 3 }}>
                <Box
                  sx={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: 64,
                    height: 64,
                    borderRadius: '50%',
                    background: 'linear-gradient(45deg, #3b82f6, #60a5fa)',
                    mb: 2.5,
                    boxShadow: '0 8px 32px rgba(59, 130, 246, 0.4)'
                  }}
                >
                  <Hotel sx={{ fontSize: 32, color: 'white' }} />
                </Box>
                <Typography
                  variant="h4"
                  sx={{
                    fontWeight: 800,
                    mb: 0.5,
                    background: 'linear-gradient(45deg, #f8fafc, #e2e8f0)',
                    backgroundClip: 'text',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    fontSize: { xs: '1.8rem', sm: '2rem' }
                  }}
                >
                  Create Account
                </Typography>
                <Typography variant="body2" sx={{ color: '#94a3b8', fontSize: '0.95rem' }}>
                  Join us to book your perfect stay
                </Typography>
              </Box>
            </Zoom>

            <form onSubmit={handleSubmit}>
              <TextField
                fullWidth
                label="Full Name"
                value={name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="John Doe"
                required
                variant="outlined"
                error={!!formErrors.name}
                helperText={formErrors.name}
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Person sx={{ color: formErrors.name ? '#ef4444' : '#94a3b8', fontSize: '1.1rem' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 2.5,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '10px',
                    backgroundColor: '#334155',
                    '& fieldset': {
                      borderColor: '#475569'
                    },
                    '&:hover fieldset': {
                      borderColor: formErrors.name ? '#ef4444' : '#3b82f6'
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: formErrors.name ? '#ef4444' : '#3b82f6',
                      borderWidth: '2px'
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: '#94a3b8',
                    '&.Mui-focused': {
                      color: formErrors.name ? '#ef4444' : '#3b82f6'
                    }
                  },
                  '& .MuiOutlinedInput-input': {
                    color: '#f8fafc',
                    '&::placeholder': {
                      color: '#64748b'
                    }
                  },
                  '& .MuiFormHelperText-root': {
                    color: '#ef4444'
                  }
                }}
              />

              <TextField
                fullWidth
                label="Email Address"
                type="email"
                value={email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="you@email.com"
                required
                variant="outlined"
                error={!!formErrors.email}
                helperText={formErrors.email}
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Email sx={{ color: formErrors.email ? '#ef4444' : '#94a3b8', fontSize: '1.1rem' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 2.5,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '10px',
                    backgroundColor: '#334155',
                    '& fieldset': {
                      borderColor: '#475569'
                    },
                    '&:hover fieldset': {
                      borderColor: formErrors.email ? '#ef4444' : '#3b82f6'
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: formErrors.email ? '#ef4444' : '#3b82f6',
                      borderWidth: '2px'
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: '#94a3b8',
                    '&.Mui-focused': {
                      color: formErrors.email ? '#ef4444' : '#3b82f6'
                    }
                  },
                  '& .MuiOutlinedInput-input': {
                    color: '#f8fafc',
                    '&::placeholder': {
                      color: '#64748b'
                    }
                  },
                  '& .MuiFormHelperText-root': {
                    color: '#ef4444'
                  }
                }}
              />

              <TextField
                fullWidth
                label="Password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                placeholder="••••••••"
                required
                variant="outlined"
                error={!!formErrors.password}
                helperText={formErrors.password}
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Lock sx={{ color: formErrors.password ? '#ef4444' : '#94a3b8', fontSize: '1.1rem' }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <Tooltip title={showPassword ? "Hide password" : "Show password"}>
                        <IconButton
                          onClick={handleTogglePasswordVisibility}
                          edge="end"
                          size="small"
                          sx={{ color: '#94a3b8' }}
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </Tooltip>
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 1,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '10px',
                    backgroundColor: '#334155',
                    '& fieldset': {
                      borderColor: '#475569'
                    },
                    '&:hover fieldset': {
                      borderColor: formErrors.password ? '#ef4444' : '#3b82f6'
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: formErrors.password ? '#ef4444' : '#3b82f6',
                      borderWidth: '2px'
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: '#94a3b8',
                    '&.Mui-focused': {
                      color: formErrors.password ? '#ef4444' : '#3b82f6'
                    }
                  },
                  '& .MuiOutlinedInput-input': {
                    color: '#f8fafc',
                    '&::placeholder': {
                      color: '#64748b'
                    }
                  },
                  '& .MuiFormHelperText-root': {
                    color: '#ef4444'
                  }
                }}
              />

              {/* Password strength indicator */}
              {password && (
                <Box sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                    <Typography variant="caption" sx={{ color: '#94a3b8' }}>
                      Password strength
                    </Typography>
                    <Typography
                      variant="caption"
                      sx={{
                        fontWeight: 600,
                        color: passwordStrength <= 25 ? '#ef4444' :
                          passwordStrength <= 50 ? '#f59e0b' :
                            passwordStrength <= 75 ? '#3b82f6' : '#10b981'
                      }}
                    >
                      {getPasswordStrengthText()}
                    </Typography>
                  </Box>
                  <LinearProgress
                    variant="determinate"
                    value={passwordStrength}
                    sx={{
                      height: 6,
                      borderRadius: 3,
                      backgroundColor: '#475569',
                      '& .MuiLinearProgress-bar': {
                        backgroundColor: passwordStrength <= 25 ? '#ef4444' :
                          passwordStrength <= 50 ? '#f59e0b' :
                            passwordStrength <= 75 ? '#3b82f6' : '#10b981',
                        borderRadius: 3
                      }
                    }}
                  />
                </Box>
              )}

              <TextField
                fullWidth
                label="Confirm Password"
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                placeholder="••••••••"
                required
                variant="outlined"
                error={!!formErrors.confirmPassword}
                helperText={formErrors.confirmPassword}
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Lock sx={{ color: formErrors.confirmPassword ? '#ef4444' : '#94a3b8', fontSize: '1.1rem' }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <Tooltip title={showConfirmPassword ? "Hide password" : "Show password"}>
                        <IconButton
                          onClick={handleToggleConfirmPasswordVisibility}
                          edge="end"
                          size="small"
                          sx={{ color: '#94a3b8' }}
                        >
                          {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </Tooltip>
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 2.5,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '10px',
                    backgroundColor: '#334155',
                    '& fieldset': {
                      borderColor: '#475569'
                    },
                    '&:hover fieldset': {
                      borderColor: formErrors.confirmPassword ? '#ef4444' : '#3b82f6'
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: formErrors.confirmPassword ? '#ef4444' : '#3b82f6',
                      borderWidth: '2px'
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: '#94a3b8',
                    '&.Mui-focused': {
                      color: formErrors.confirmPassword ? '#ef4444' : '#3b82f6'
                    }
                  },
                  '& .MuiOutlinedInput-input': {
                    color: '#f8fafc',
                    '&::placeholder': {
                      color: '#64748b'
                    }
                  },
                  '& .MuiFormHelperText-root': {
                    color: '#ef4444'
                  }
                }}
              />

              {error && (
                <Fade in timeout={300}>
                  <Alert
                    severity="error"
                    icon={<Error />}
                    sx={{
                      mb: 2.5,
                      borderRadius: '10px',
                      backgroundColor: 'rgba(239, 68, 68, 0.1)',
                      border: '1px solid rgba(239, 68, 68, 0.3)',
                      color: '#fecaca',
                      '& .MuiAlert-icon': {
                        color: '#ef4444',
                        fontSize: '1.25rem'
                      }
                    }}
                  >
                    {error}
                  </Alert>
                </Fade>
              )}

              {message && (
                <Fade in timeout={300}>
                  <Alert
                    severity="success"
                    icon={<CheckCircle />}
                    sx={{
                      mb: 2.5,
                      borderRadius: '10px',
                      backgroundColor: 'rgba(34, 197, 94, 0.1)',
                      border: '1px solid rgba(34, 197, 94, 0.3)',
                      color: '#bbf7d0',
                      '& .MuiAlert-icon': {
                        color: '#10b981',
                        fontSize: '1.25rem'
                      }
                    }}
                  >
                    {message}
                  </Alert>
                </Fade>
              )}

              <Button
                type="submit"
                variant="contained"
                fullWidth
                size="medium"
                startIcon={loading ? <CircularProgress size={18} color="inherit" /> : <PersonAdd />}
                disabled={loading}
                sx={{
                  borderRadius: '20px',
                  textTransform: 'none',
                  fontWeight: 700,
                  fontSize: '1rem',
                  py: 1.5,
                  mb: 2.5,
                  background: 'linear-gradient(45deg, #3b82f6, #60a5fa)',
                  boxShadow: '0 8px 25px rgba(59, 130, 246, 0.4)',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    background: 'linear-gradient(45deg, #2563eb, #3b82f6)',
                    transform: 'translateY(-2px)',
                    boxShadow: '0 12px 30px rgba(59, 130, 246, 0.5)'
                  },
                  '&:disabled': {
                    background: '#475569',
                    transform: 'none',
                    boxShadow: 'none'
                  }
                }}
              >
                {loading ? "Creating Account..." : "Create Account"}
              </Button>
            </form>

            <Divider sx={{ my: 2.5, borderColor: '#475569' }}>
              <Typography variant="body2" sx={{ px: 2, fontWeight: 600, color: '#94a3b8', fontSize: '0.85rem' }}>
                OR
              </Typography>
            </Divider>

            <Box sx={{ textAlign: 'center' }}>
              <Typography variant="body2" sx={{ mb: 2, color: '#94a3b8', fontSize: '0.9rem' }}>
                Already have an account?
              </Typography>
              <Button
                component={Link}
                to="/login"
                variant="outlined"
                size="medium"
                fullWidth
                sx={{
                  borderRadius: '20px',
                  textTransform: 'none',
                  fontWeight: 600,
                  py: 1.25,
                  mb: 1.5,
                  borderColor: '#3b82f6',
                  color: '#60a5fa',
                  borderWidth: '1.5px',
                  backgroundColor: 'transparent',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    transform: 'translateY(-1px)',
                    color: '#3b82f6'
                  }
                }}
              >
                Sign In
              </Button>

              <Button
                component={Link}
                to="/admin-register"
                variant="text"
                size="small"
                startIcon={<AdminPanelSettings />}
                sx={{
                  textTransform: 'none',
                  fontWeight: 600,
                  color: '#f87171',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    backgroundColor: 'rgba(220, 38, 38, 0.1)',
                    transform: 'translateY(-1px)',
                    color: '#ef4444'
                  }
                }}
              >
                Register as Administrator
              </Button>
            </Box>
          </Paper>
        </Fade>
      </Container>

      {/* Success Snackbar */}
      <Snackbar
        open={showSuccess}
        autoHideDuration={3000}
        onClose={handleCloseSuccess}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        TransitionComponent={Slide}
      >
        <Alert
          onClose={handleCloseSuccess}
          severity="success"
          sx={{
            width: '100%',
            backgroundColor: '#065f46',
            color: '#d1fae5'
          }}
        >
          Registration successful! Redirecting to login...
        </Alert>
      </Snackbar>

      <style jsx>{`
     @keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
    }
   `}</style>
    </Box>
  );
}
