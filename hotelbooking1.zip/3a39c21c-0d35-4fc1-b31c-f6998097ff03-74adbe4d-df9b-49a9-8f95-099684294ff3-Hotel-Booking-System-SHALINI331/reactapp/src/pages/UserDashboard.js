// import React from 'react';
// import BookingList from '../components/BookingList';

// export default function UserDashboard() {
//   return (
//     <div>
//       <h2 style={{ color: '#3730a3', marginBottom: 16 }}>Your Bookings</h2>
//       <BookingList />
//     </div>
//   );
// }


// src/pages/UserDashboard.js
import React from 'react';
import BookingList from '../components/BookingList';

export default function UserDashboard() {
  // const [rooms, setRooms] = useState([]);
  // const [loading, setLoading] = useState(true);

  // useEffect(() => {
  //   fetch('https://8080-feebdeabdbfcdbbbeadbeddfbafff.premiumproject.examly.io/api/rooms/available')
  //   .then(res => res.json())
  //   .then(data => {
  //     setRooms(data);
  //     setLoading(false);
  //     })
  //     .catch(err => console.error(err));
  //   }, []);

  //   const handleBook = (roomId) => {
  //     fetch(`https://8080-feebdeabdbfcdbbbeadbeddfbafff.premiumproject.examly.io/api/bookings`, {
  //       method: 'POST',
  //       headers: { 'Content-Type': 'application/json' },
  //       body: JSON.stringify({
  //         roomId,
  //         userId: localStorage.getItem('userId'), // Assuming stored at login
  //         bookingDate: new Date()
  //         })
  //         })
  //         .then(res => res.json())
  //         .then(() => {
  //           alert('Room booked successfully!');
  //         })
  //         .catch(err => console.error(err));
  //         };

  return (
    <div>
      <h2 style={{ color: '#3730a3', marginBottom: 16 }}>Your Bookings</h2>
      <BookingList />

      {/* <h2 style={{ color: '#3730a3', margin: '16px 0' }}>Available Rooms</h2>
              {loading ? <p>Loading...</p> : (
                <ul>
                  {rooms.map(room => (
                    <li key={room.id} style={{ marginBottom: '8px' }}>
                      <strong>{room.roomType}</strong> — ${room.price}  
                      {room.available && (
                        <button
                        style={{ marginLeft: '10px' }}
                        onClick={() => handleBook(room.id)}
                        >
                          Book Now
                          </button>
                      )}
                      </li>
                      ))}
                      </ul> */}
      {/* )} */}
    </div>
  );
}
