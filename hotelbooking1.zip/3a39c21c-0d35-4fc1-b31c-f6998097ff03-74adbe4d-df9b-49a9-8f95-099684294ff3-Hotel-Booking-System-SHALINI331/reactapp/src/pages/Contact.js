import React, { useState } from 'react';
import { Box, Container, Typography, TextField, Button, Paper, Grid, Alert, Divider, Card, CardContent } from '@mui/material';
import { Email, Phone, LocationOn, AccessTime, Send, Business, Support } from '@mui/icons-material';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const onSubmit = (e) => {
    e.preventDefault();
    setSent(true);
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h2" sx={{ fontWeight: 700, mb: 2, background: 'linear-gradient(45deg, #3b82f6, #60a5fa)', backgroundClip: 'text', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          Contact Us
        </Typography>
        <Typography variant="h6" color="text.secondary" sx={{ maxWidth: 600, mx: 'auto', lineHeight: 1.6 }}>
          Have questions or need assistance? We're here to help! Reach out to us and we'll get back to you as soon as possible.
        </Typography>
      </Box>

      {/* Get in Touch Section - Horizontal Layout */}
      <Card sx={{ mb: 6, borderRadius: 3, boxShadow: 3 }}>
        <CardContent sx={{ p: 4 }}>
          <Typography variant="h4" sx={{ fontWeight: 700, mb: 4, color: 'primary.main', textAlign: 'center' }}>
            Get in Touch
          </Typography>
          
          <Grid container spacing={4} justifyContent="center">
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <Email sx={{ color: 'primary.main', fontSize: 40, mb: 2 }} />
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>Email</Typography>
                <Typography variant="body1" color="text.secondary">info@stayease.com</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  We'll respond within 24 hours
                </Typography>
              </Box>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <Phone sx={{ color: 'primary.main', fontSize: 40, mb: 2 }} />
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>Phone</Typography>
                <Typography variant="body1" color="text.secondary">+1 (555) 123-4567</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  Available 24/7 for urgent matters
                </Typography>
              </Box>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <LocationOn sx={{ color: 'primary.main', fontSize: 40, mb: 2 }} />
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>Address</Typography>
                <Typography variant="body1" color="text.secondary">
                  123 Hotel Street<br />
                  City, State 12345
                </Typography>
              </Box>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <AccessTime sx={{ color: 'primary.main', fontSize: 40, mb: 2 }} />
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>Business Hours</Typography>
                <Typography variant="body1" color="text.secondary">
                  Mon-Fri: 8AM-10PM<br />
                  Sat-Sun: 9AM-11PM
                </Typography>
              </Box>
            </Grid>
          </Grid>

          <Divider sx={{ my: 4 }} />

          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
              Follow Us
            </Typography>
            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button
                variant="outlined"
                size="small"
                startIcon={<Business />}
                sx={{ borderRadius: '20px', textTransform: 'none' }}
              >
                LinkedIn
              </Button>
              <Button
                variant="outlined"
                size="small"
                startIcon={<Support />}
                sx={{ borderRadius: '20px', textTransform: 'none' }}
              >
                Support
              </Button>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Contact Form */}
      <Paper sx={{ p: 4, borderRadius: 3, boxShadow: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 3, color: 'primary.main', textAlign: 'center' }}>
          Send us a Message
        </Typography>
        
        <form onSubmit={onSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Jane Doe"
                required
                variant="outlined"
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Email Address"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                required
                variant="outlined"
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Message"
                multiline
                rows={6}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="How can we help you? Please provide details about your inquiry..."
                required
                variant="outlined"
              />
            </Grid>
            
            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                size="large"
                fullWidth
                startIcon={<Send />}
                sx={{
                  borderRadius: '25px',
                  textTransform: 'none',
                  fontWeight: 600,
                  fontSize: '1.1rem',
                  py: 1.5,
                  background: 'linear-gradient(45deg, #3b82f6, #60a5fa)',
                  '&:hover': {
                    background: 'linear-gradient(45deg, #2563eb, #3b82f6)'
                  }
                }}
              >
                Send Message
              </Button>
            </Grid>
          </Grid>
        </form>
        
        {sent && (
          <Alert severity="success" sx={{ mt: 3 }}>
            <Typography variant="body1" sx={{ fontWeight: 600 }}>
              Message sent successfully!
            </Typography>
            <Typography variant="body2">
              We will get back to you within 24 hours.
            </Typography>
          </Alert>
        )}
      </Paper>
    </Container>
  );
}


