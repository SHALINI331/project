
import React, { useEffect, useState } from 'react';
import { getBookings, updateBookingStatus, adminCreateRoom } from '../utils/api';
import {
    Box,
    Container,
    Typography,
    Button,
    Paper,
    TextField,
    FormControlLabel,
    Checkbox,
    Grid,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Alert,
    Divider,
    Card,
    CardContent
} from '@mui/material';
import { Add, CheckCircle, Cancel, Hotel } from '@mui/icons-material';

export default function AdminPanel() {
    const [bookings, setBookings] = useState([]);
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const [showCreateRoom, setShowCreateRoom] = useState(false);
    const [roomForm, setRoomForm] = useState({
        roomNumber: '',
        roomType: '',
        capacity: '',
        price: '',
        available: true,
        imageUrl: '',
        description: ''
    });

    const fetchBookings = async () => {
        try {
            const { data } = await getBookings();
            setBookings(data.filter(b => b.status === 'PENDING'));
        } catch {
            setError('Error loading bookings');
        }
    };

    useEffect(() => { fetchBookings(); }, []);

    const handleAction = async (id, status) => {
        try {
            await updateBookingStatus(id, status);
            setMessage(`Booking ${id} has been ${status === 'APPROVED' ? 'approved' : 'rejected'}`);
            fetchBookings();
        } catch {
            setError('Update error');
        }
    };

    const handleCreateRoom = async (e) => {
        e.preventDefault();
        setError('');
        setMessage('');
        try {
            await adminCreateRoom({
                roomNumber: roomForm.roomNumber,
                roomType: roomForm.roomType,
                capacity: parseInt(roomForm.capacity, 10),
                price: parseFloat(roomForm.price),
                available: roomForm.available,
                imageUrl: roomForm.imageUrl || 'https://images.unsplash.com/photo-1560066984-138dadb4c035?q=80&w=1600&auto=format&fit=crop',
                description: roomForm.description || 'A beautiful room for your stay.'
            });
            setMessage('Room created successfully!');
            setShowCreateRoom(false);
            setRoomForm({ roomNumber: '', roomType: '', capacity: '', price: '', available: true, imageUrl: '', description: '' });

            // Trigger storage event to notify other components about the new room
            window.dispatchEvent(new StorageEvent('storage', {
                key: 'hotel_app_rooms',
                newValue: localStorage.getItem('hotel_app_rooms')
            }));
        } catch (err) {
            setError(err.message || 'Failed to create room');
        }
    };

    return (
        <Container maxWidth="lg" sx={{ py: 4 }}>
            <Box sx={{ mb: 4 }}>
                <Typography variant="h3" sx={{ fontWeight: 700, mb: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
                    <Hotel sx={{ color: 'primary.main' }} />
                    Admin Dashboard
                </Typography>
                <Typography variant="body1" color="text.secondary">
                    Manage bookings and create new rooms for your hotel
                </Typography>
            </Box>

            {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
            {message && <Alert severity="success" sx={{ mb: 3 }}>{message}</Alert>}

            <Card sx={{ mb: 4, borderRadius: 3, boxShadow: 3 }}>
                <CardContent sx={{ p: 4 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                        <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>
                            Room Management
                        </Typography>
                        <Button
                            variant={showCreateRoom ? "outlined" : "contained"}
                            startIcon={<Add />}
                            onClick={() => setShowCreateRoom(!showCreateRoom)}
                            sx={{
                                borderRadius: '25px',
                                textTransform: 'none',
                                fontWeight: 600,
                                px: 3
                            }}
                        >
                            {showCreateRoom ? 'Cancel' : 'Create New Room'}
                        </Button>
                    </Box>

                    {showCreateRoom && (
                        <Paper sx={{ p: 4, borderRadius: 3, boxShadow: 2 }}>
                            <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                                Create New Room
                            </Typography>

                            <form onSubmit={handleCreateRoom}>
                                <Grid container spacing={3}>
                                    <Grid item xs={12} sm={6}>
                                        <TextField
                                            fullWidth
                                            label="Room Number"
                                            value={roomForm.roomNumber}
                                            onChange={e => setRoomForm(f => ({ ...f, roomNumber: e.target.value }))}
                                            placeholder="101"
                                            required
                                            variant="outlined"
                                        />
                                    </Grid>

                                    <Grid item xs={12} sm={6}>
                                        <TextField
                                            fullWidth
                                            label="Room Type"
                                            value={roomForm.roomType}
                                            onChange={e => setRoomForm(f => ({ ...f, roomType: e.target.value }))}
                                            placeholder="Deluxe, Suite, Premium..."
                                            required
                                            variant="outlined"
                                        />
                                    </Grid>

                                    <Grid item xs={12} sm={6}>
                                        <TextField
                                            fullWidth
                                            label="Capacity"
                                            type="number"
                                            min="1"
                                            value={roomForm.capacity}
                                            onChange={e => setRoomForm(f => ({ ...f, capacity: e.target.value }))}
                                            placeholder="2"
                                            required
                                            variant="outlined"
                                        />
                                    </Grid>

                                    <Grid item xs={12} sm={6}>
                                        <TextField
                                            fullWidth
                                            label="Price per Night"
                                            type="number"
                                            min="0"
                                            step="0.01"
                                            value={roomForm.price}
                                            onChange={e => setRoomForm(f => ({ ...f, price: e.target.value }))}
                                            placeholder="1000"
                                            required
                                            variant="outlined"
                                        />
                                    </Grid>

                                    <Grid item xs={12}>
                                        <TextField
                                            fullWidth
                                            label="Image URL (optional)"
                                            type="url"
                                            value={roomForm.imageUrl}
                                            onChange={e => setRoomForm(f => ({ ...f, imageUrl: e.target.value }))}
                                            placeholder="https://example.com/image.jpg"
                                            variant="outlined"
                                            helperText="Leave empty to use default image"
                                        />
                                    </Grid>

                                    <Grid item xs={12}>
                                        <TextField
                                            fullWidth
                                            label="Description (optional)"
                                            multiline
                                            rows={3}
                                            value={roomForm.description}
                                            onChange={e => setRoomForm(f => ({ ...f, description: e.target.value }))}
                                            placeholder="Describe the room features and amenities..."
                                            variant="outlined"
                                        />
                                    </Grid>

                                    <Grid item xs={12}>
                                        <FormControlLabel
                                            control={
                                                <Checkbox
                                                    checked={roomForm.available}
                                                    onChange={e => setRoomForm(f => ({ ...f, available: e.target.checked }))}
                                                    color="primary"
                                                />
                                            }
                                            label="Room is available for booking"
                                        />
                                    </Grid>

                                    <Grid item xs={12}>
                                        <Button
                                            type="submit"
                                            variant="contained"
                                            size="large"
                                            fullWidth
                                            sx={{
                                                borderRadius: '25px',
                                                textTransform: 'none',
                                                fontWeight: 600,
                                                py: 1.5,
                                                background: 'linear-gradient(45deg, #3b82f6, #60a5fa)',
                                                '&:hover': {
                                                    background: 'linear-gradient(45deg, #2563eb, #3b82f6)'
                                                }
                                            }}
                                        >
                                            Create Room
                                        </Button>
                                    </Grid>
                                </Grid>
                            </form>
                        </Paper>
                    )}
                </CardContent>
            </Card>

            <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
                <CardContent sx={{ p: 4 }}>
                    <Typography variant="h5" sx={{ fontWeight: 700, mb: 3, color: 'primary.main' }}>
                        Pending Bookings
                    </Typography>

                    {bookings.length === 0 ? (
                        <Box sx={{ textAlign: 'center', py: 4 }}>
                            <Typography variant="h6" color="text.secondary">
                                No pending bookings at the moment
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                All bookings have been processed
                            </Typography>
                        </Box>
                    ) : (
                        <TableContainer>
                            <Table>
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{ fontWeight: 600 }}>Guest Name</TableCell>
                                        <TableCell sx={{ fontWeight: 600 }}>Room Number</TableCell>
                                        <TableCell sx={{ fontWeight: 600 }}>Check-In Date</TableCell>
                                        <TableCell sx={{ fontWeight: 600 }}>Check-Out Date</TableCell>
                                        <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {bookings.map(b => (
                                        <TableRow key={b.bookingId} hover>
                                            <TableCell>{b.guestName}</TableCell>
                                            <TableCell>{b.room?.roomNumber}</TableCell>
                                            <TableCell>{new Date(b.checkInDate).toLocaleDateString()}</TableCell>
                                            <TableCell>{new Date(b.checkOutDate).toLocaleDateString()}</TableCell>
                                            <TableCell>
                                                <Box sx={{ display: 'flex', gap: 1 }}>
                                                    <Button
                                                        variant="contained"
                                                        size="small"
                                                        startIcon={<CheckCircle />}
                                                        onClick={() => handleAction(b.bookingId, 'APPROVED')}
                                                        sx={{
                                                            borderRadius: '20px',
                                                            textTransform: 'none',
                                                            fontWeight: 600,
                                                            bgcolor: 'success.main',
                                                            '&:hover': { bgcolor: 'success.dark' }
                                                        }}
                                                    >
                                                        Approve
                                                    </Button>
                                                    <Button
                                                        variant="contained"
                                                        size="small"
                                                        startIcon={<Cancel />}
                                                        onClick={() => handleAction(b.bookingId, 'REJECTED')}
                                                        sx={{
                                                            borderRadius: '20px',
                                                            textTransform: 'none',
                                                            fontWeight: 600,
                                                            bgcolor: 'error.main',
                                                            '&:hover': { bgcolor: 'error.dark' }
                                                        }}
                                                    >
                                                        Reject
                                                    </Button>
                                                </Box>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    )}
                </CardContent>
            </Card>
        </Container>
    );
}
