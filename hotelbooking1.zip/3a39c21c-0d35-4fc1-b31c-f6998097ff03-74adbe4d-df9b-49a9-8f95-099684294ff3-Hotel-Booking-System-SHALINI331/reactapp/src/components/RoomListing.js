import React, { useEffect, useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getRooms } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import {
    Card,
    CardActions,
    CardContent,
    CardMedia,
    Typography,
    Button,
    Grid,
    FormControlLabel,
    Checkbox,
    Box,
    Chip,
    Container,
    TextField,
    MenuItem
} from '@mui/material';
import { Refresh } from '@mui/icons-material';

export default function RoomListing() {
    const [rooms, setRooms] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [showAvailableOnly, setShowAvailableOnly] = useState(false);

    // NEW STATES
    const [searchQuery, setSearchQuery] = useState('');
    const [sortOption, setSortOption] = useState('');
    const [filterType, setFilterType] = useState(''); // for filtering by room type

    const navigate = useNavigate();
    const { currentUser } = useAuth();

    // Fallback hotel room images
    const FALLBACK_IMAGES = [
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=1600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1505691938895-1758d7feb511?q=80&w=1600&auto=format&fit=crop",
        "https://plus.unsplash.com/premium_photo-1670360414903-19e5832f8bc4?w=500&auto=format&fit=crop&q=60",
        "https://images.unsplash.com/photo-1554995207-c18c203602cb?q=80&w=1600&auto=format&fit=crop"
    ];

    const getRoomImage = (room) => {
        if (room?.imageUrl) return room.imageUrl;
        const key = String(room?.roomId ?? room?.roomNumber ?? '');
        let hash = 0;
        for (let i = 0; i < key.length; i++) {
            hash = ((hash * 31) + key.charCodeAt(i)) >>> 0;
        }
        const idx = key ? hash % FALLBACK_IMAGES.length : 0;
        return FALLBACK_IMAGES[idx];
    };

    const fetchRooms = async () => {
        setLoading(true);
        try {
            const { data } = await getRooms(showAvailableOnly);
            setRooms(data);
        } catch (err) {
            setError('Could not load rooms');
        } finally {
            setLoading(false);
        }
    };

    const handleRefresh = () => {
        fetchRooms();
    };

    useEffect(() => {
        fetchRooms();
        // eslint-disable-next-line
    }, [showAvailableOnly]);

    // ------------------------------
    // SEARCH + SORT + FILTER LOGIC
    // ------------------------------
    const processedRooms = useMemo(() => {
        let result = [...rooms];

        // Sort
        if (sortOption === 'priceLowHigh') {
            result.sort((a, b) => (a.pricePerNight || a.price) - (b.pricePerNight || b.price));
        } else if (sortOption === 'priceHighLow') {
            result.sort((a, b) => (b.pricePerNight || b.price) - (a.pricePerNight || a.price));
        } else if (sortOption === 'capacity') {
            result.sort((a, b) => b.capacity - a.capacity);
        }

        // Mark matches
        return result.map(room => {
            const matchesSearch = searchQuery
                ? room.roomNumber?.toString().toLowerCase().includes(searchQuery.toLowerCase()) ||
                room.roomType?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                room.description?.toLowerCase().includes(searchQuery.toLowerCase())
                : true;

            const matchesFilter = filterType ? room.roomType === filterType : true;

            return { ...room, matches: matchesSearch && matchesFilter };
        });
    }, [rooms, searchQuery, sortOption, filterType]);
    // ------------------------------

    if (loading) return <div className="loading">Loading rooms...</div>;
    if (error) return <div className="error">{error}</div>;

    return (
        <Container maxWidth="lg" sx={{ py: 4 }}>
            <Box
                sx={{
                    mb: 4,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    gap: 2
                }}
            >
                <FormControlLabel
                    control={
                        <Checkbox
                            checked={showAvailableOnly}
                            onChange={() => setShowAvailableOnly(!showAvailableOnly)}
                            sx={{ color: 'primary.main' }}
                        />
                    }
                    label="Show available only"
                />

                {/* Search Box */}
                <TextField
                    size="small"
                    variant="outlined"
                    placeholder="Search rooms..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    sx={{ width: 200 }}
                />

                {/* Filter by Type */}
                <TextField
                    select
                    size="small"
                    label="Filter by Type"
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    sx={{ width: 160 }}
                    displayEmpty
                >
                    <MenuItem value="">All Types</MenuItem>
                    <MenuItem value="Deluxe">Deluxe</MenuItem>
                    <MenuItem value="Suite">Suite</MenuItem>
                    <MenuItem value="Standard">Standard</MenuItem>
                </TextField>

                {/* Sort Options */}
                <TextField
                    select
                    size="small"
                    label="Sort By"
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value)}
                    sx={{ width: 180 }}
                    displayEmpty
                >
                    <MenuItem value="">Sort By</MenuItem>
                    <MenuItem value="priceLowHigh">Price: Low to High</MenuItem>
                    <MenuItem value="priceHighLow">Price: High to Low</MenuItem>
                    <MenuItem value="capacity">Capacity</MenuItem>
                </TextField>

                <Button
                    variant="outlined"
                    startIcon={<Refresh />}
                    onClick={handleRefresh}
                    sx={{ borderRadius: '20px', textTransform: 'none' }}
                >
                    Refresh
                </Button>
            </Box>

            {/* Visible card layout */}
            <Grid container spacing={2}>
                {processedRooms.map(room => (
                    <Grid item key={room.roomId} xs={12} sm={6} md={3}>
                        <Card
                            sx={{
                                height: '400px',
                                display: 'flex',
                                flexDirection: 'column',
                                transition: 'transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out',
                                opacity: room.matches ? 1 : 0.4, // dim non-matching rooms
                                '&:hover': {
                                    transform: 'translateY(-4px)',
                                    boxShadow: '0 8px 25px rgba(0,0,0,0.3)'
                                }
                            }}
                        >
                            <CardMedia
                                component="img"
                                height="180"
                                image={getRoomImage(room)}
                                alt={room.roomType || 'Hotel room'}
                                sx={{ objectFit: 'cover' }}
                            />
                            <CardContent sx={{ flexGrow: 1, p: 1.5, display: 'flex', flexDirection: 'column' }}>
                                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                                    <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '0.9rem' }}>
                                        {room.roomNumber}
                                    </Typography>
                                    <Chip
                                        label={room.available ? 'Available' : 'Booked'}
                                        color={room.available ? 'success' : 'error'}
                                        size="small"
                                        sx={{ fontSize: '0.65rem' }}
                                    />
                                </Box>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    sx={{ mb: 0.5, fontSize: '0.8rem' }}
                                >
                                    {room.roomType} • Capacity {room.capacity}
                                </Typography>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    sx={{
                                        mb: 1.5,
                                        fontSize: '0.75rem',
                                        lineHeight: 1.3,
                                        flexGrow: 1,
                                        display: '-webkit-box',
                                        WebkitLineClamp: 2,
                                        WebkitBoxOrient: 'vertical',
                                        overflow: 'hidden',
                                        minHeight: '2.6em'
                                    }}
                                >
                                    {room.description || 'Modern room with all amenities.'}
                                </Typography>
                                <Typography
                                    variant="h6"
                                    sx={{ fontWeight: 700, color: 'primary.main', fontSize: '1rem' }}
                                >
                                    ₹{room.pricePerNight || room.price} / night
                                </Typography>
                            </CardContent>
                            <CardActions sx={{ p: 1.5, pt: 0, gap: 0.5 }}>
                                <Button
                                    component={Link}
                                    to={`/rooms/${room.roomId}`}
                                    size="small"
                                    variant="outlined"
                                    sx={{
                                        flex: 1,
                                        borderRadius: '15px',
                                        textTransform: 'none',
                                        fontWeight: 600,
                                        fontSize: '0.75rem',
                                        py: 0.5
                                    }}
                                >
                                    Details
                                </Button>

                                <Button
                                    size="small"
                                    variant="contained"
                                    disabled={!room.available}
                                    onClick={() => {
                                        if (!currentUser) {
                                            navigate('/login');
                                        } else if (currentUser.role === 'ADMIN') {
                                            navigate('/admin');
                                        } else {
                                            navigate(`/rooms/${room.roomId}`, {
                                                state: {
                                                    roomId: room.roomId,
                                                    roomNumber: room.roomNumber,
                                                    roomType: room.roomType,
                                                    pricePerNight: room.pricePerNight || room.price,
                                                    capacity: room.capacity,
                                                    imageUrl: getRoomImage(room)
                                                }
                                            });
                                        }
                                    }}
                                    sx={{
                                        borderRadius: '20px',
                                        textTransform: 'none',
                                        fontWeight: 'bold'
                                    }}
                                >
                                    Book Now
                                </Button>
                            </CardActions>
                        </Card>
                    </Grid>
                ))}
            </Grid>
        </Container>
    );
}
