import React from 'react';
import { Box, Container, Link, Stack, Typography, Grid } from '@mui/material';

export default function Footer() {
  return (
    <Box component="footer" sx={{ py: 4, mt: 6, bgcolor: 'background.paper', borderTop: '1px solid', borderColor: 'divider' }}>
      <Container maxWidth="lg">
        <Grid container spacing={4} justifyContent="space-between">
          <Grid item xs={12} sm={6} md={2.5}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 700 }}>StayEase</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              Your perfect stay awaits. Book with confidence and comfort.
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6} md={2.5}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 700 }}>Contact Info</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              📧 info@stayease.com
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              📞 +1 (555) 123-4567
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              📍 123 Hotel Street, City, State 12345
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6} md={2.5}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 700 }}>Quick Links</Typography>
            <Stack spacing={1}>
              <Link href="#" color="inherit" underline="hover">Privacy Policy</Link>
              <Link href="#" color="inherit" underline="hover">Terms of Service</Link>
              <Link href="#" color="inherit" underline="hover">Support</Link>
              <Link href="#" color="inherit" underline="hover">About Us</Link>
            </Stack>
          </Grid>
          <Grid item xs={12} sm={6} md={2.5}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 700 }}>Services</Typography>
            <Stack spacing={1}>
              <Link href="#" color="inherit" underline="hover">Room Booking</Link>
              <Link href="#" color="inherit" underline="hover">Conference Rooms</Link>
              <Link href="#" color="inherit" underline="hover">Spa & Wellness</Link>
              <Link href="#" color="inherit" underline="hover">Restaurant</Link>
            </Stack>
          </Grid>
        </Grid>
        <Box sx={{ mt: 3, pt: 2, borderTop: '1px solid', borderColor: 'divider' }}>
          <Typography variant="body2" color="text.secondary" align="center">
            © {new Date().getFullYear()} StayEase — All rights reserved.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
}


