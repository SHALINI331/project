// import React, { useState } from 'react';
// import { createBooking, getAllRooms } from '../utils/api';

// export default function BookingForm({ room, onClose }) {
//     const [guestName, setGuestName] = useState('');
//     const [guestEmail, setGuestEmail] = useState('');
//     const [checkInDate, setCheckInDate] = useState('');
//     const [checkOutDate, setCheckOutDate] = useState('');
//     const [errors, setErrors] = useState({});
//     const [message, setMessage] = useState(null);
//     const [submitting, setSubmitting] = useState(false);

//     const validate = () => {
//         const errs = {};
//         if (!guestName.trim()) errs.name = 'Name is required';
//         if (!guestEmail.trim()) errs.email = 'Email is required';
//         else if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(guestEmail)) errs.email = 'Invalid email format';
//         if (!checkInDate) errs.checkIn = 'Check-in is required';
//         if (!checkOutDate) errs.checkOut = 'Check-out is required';
//         else if (checkInDate && checkOutDate && checkOutDate <= checkInDate)
//             errs.dateOrder = 'Check-out date must be after check-in';
//         return errs;
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         setMessage(null);
//         const errs = validate();
//         setErrors(errs);
//         if (Object.keys(errs).length > 0) return;

//         try {
//             setSubmitting(true);
//             // Determine a numeric roomId. When rooms are seeded locally the id may be a string;
//             // resolve it by looking up the room from backend using roomNumber.
//             let roomIdToUse = room && (room.roomId || room.id);
//             if (roomIdToUse && typeof roomIdToUse === 'string') {
//                 const parsed = parseInt(roomIdToUse, 10);
//                 if (!Number.isFinite(parsed)) {
//                     try {
//                         const backendRooms = await getAllRooms();
//                         const match = backendRooms.find(r => String(r.roomNumber) === String(room && room.roomNumber));
//                         if (match) {
//                             roomIdToUse = match.roomId ?? match.id;
//                         }
//                     } catch { }
//                 } else {
//                     roomIdToUse = parsed;
//                 }
//             }

//             await createBooking({
//                 guestName,
//                 guestEmail,
//                 checkInDate,  // 'YYYY-MM-DD' from <input type="date" />
//                 checkOutDate,
//                 roomId: roomIdToUse,
//             });

//             setMessage('Booking created successfully');
//             setGuestName('');
//             setGuestEmail('');
//             setCheckInDate('');
//             setCheckOutDate('');
//         } catch (err) {
//             setMessage(err.message || 'Booking failed due to backend');
//         } finally {
//             setSubmitting(false);
//         }
//     };

//     return (
//         <form onSubmit={handleSubmit} className="booking-form">
//             <div>
//                 <label htmlFor="guestName" style={{color:"black"}}>Guest Name</label>
//                 <input
//                     id="guestName"
//                     value={guestName}
//                     onChange={(e) => setGuestName(e.target.value)}
//                     placeholder="Enter your name"
//                 />
//                 {errors.name && <div className="form-error">{errors.name}</div>}
//             </div>

//             <div>
//                 <label htmlFor="guestEmail" style={{color:"black"}}>Guest Email</label>
//                 <input
//                     id="guestEmail"
//                     value={guestEmail}
//                     onChange={(e) => setGuestEmail(e.target.value)}
//                     placeholder="you@email.com"
//                 />
//                 {errors.email && <div className="form-error">{errors.email}</div>}
//             </div>

//             <div>
//                 <label htmlFor="checkInDate" style={{color:"black"}}>Check-In</label>
//                 <input
//                     id="checkInDate"
//                     type="date"
//                     value={checkInDate}
//                     onChange={(e) => setCheckInDate(e.target.value)}
//                 />
//                 {errors.checkIn && <div className="form-error">{errors.checkIn}</div>}
//             </div>

//             <div>
//                 <label htmlFor="checkOutDate" style={{color:"black"}}>Check-Out</label>
//                 <input
//                     id="checkOutDate"
//                     type="date"
//                     value={checkOutDate}
//                     onChange={(e) => setCheckOutDate(e.target.value)}
//                 />
//                 {errors.checkOut && <div className="form-error">{errors.checkOut}</div>}
//                 {errors.dateOrder && <div className="form-error">{errors.dateOrder}</div>}
//             </div>

//             <div className="booking-form-actions">
//                 <button type="submit" className="booking-form-submit" disabled={submitting}>
//                     {submitting ? 'Creating…' : 'Create Booking'}
//                 </button>
//                 {!!onClose && (
//                     <button type="button" onClick={onClose} className="booking-form-close">Close</button>
//                 )}
//             </div>

//             {message && (
//                 <div className={message.includes('success') ? 'success' : 'form-error'} style={{ marginTop: '1rem' }}>
//                     {message}
//                 </div>
//             )}
//         </form>
//     );
// }


import React, { useState, useEffect } from 'react';
import { createBooking, getAllRooms } from '../utils/api';

export default function BookingForm({ room, onClose }) {
    const [guestName, setGuestName] = useState('');
    const [guestEmail, setGuestEmail] = useState('');
    const [checkInDate, setCheckInDate] = useState('');
    const [checkOutDate, setCheckOutDate] = useState('');
    const [errors, setErrors] = useState({});
    const [message, setMessage] = useState(null);
    const [submitting, setSubmitting] = useState(false);

    // ✅ Auto-fill from login info in localStorage
    useEffect(() => {
        try {
            const storedUser = localStorage.getItem("user"); // assume login saved it
            if (storedUser) {
                const parsed = JSON.parse(storedUser);
                if (parsed.name) setGuestName(parsed.name);
                if (parsed.email) setGuestEmail(parsed.email);
            }
        } catch (err) {
            console.error("Error reading user from localStorage", err);
        }
    }, []);

    const validate = () => {
        const errs = {};
        if (!guestName.trim()) errs.name = 'Name is required';
        if (!guestEmail.trim()) errs.email = 'Email is required';
        else if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(guestEmail)) errs.email = 'Invalid email format';
        if (!checkInDate) errs.checkIn = 'Check-in is required';
        if (!checkOutDate) errs.checkOut = 'Check-out is required';
        else if (checkInDate && checkOutDate && checkOutDate <= checkInDate)
            errs.dateOrder = 'Check-out date must be after check-in';
        return errs;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage(null);
        const errs = validate();
        setErrors(errs);
        if (Object.keys(errs).length > 0) return;

        try {
            setSubmitting(true);

            let roomIdToUse = room && (room.roomId || room.id);
            if (roomIdToUse && typeof roomIdToUse === 'string') {
                const parsed = parseInt(roomIdToUse, 10);
                if (!Number.isFinite(parsed)) {
                    try {
                        const backendRooms = await getAllRooms();
                        const match = backendRooms.find(r => String(r.roomNumber) === String(room && room.roomNumber));
                        if (match) {
                            roomIdToUse = match.roomId ?? match.id;
                        }
                    } catch { }
                } else {
                    roomIdToUse = parsed;
                }
            }

            await createBooking({
                guestName,
                guestEmail,
                checkInDate,
                checkOutDate,
                roomId: roomIdToUse,
            });

            setMessage('Booking created successfully');
            setCheckInDate('');
            setCheckOutDate('');
            // 👇 Name & email remain prefilled (from login), not reset
        } catch (err) {
            setMessage(err.message || 'Booking failed due to backend');
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="booking-form">
            <div>
                <label htmlFor="guestName" style={{ color: "black" }}>Guest Name</label>
                <input
                    id="guestName"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="Enter your name"
                    readOnly // prevent overwriting login user
                />
                {errors.name && <div className="form-error">{errors.name}</div>}
            </div>

            <div>
                <label htmlFor="guestEmail" style={{ color: "black" }}>Guest Email</label>
                <input
                    id="guestEmail"
                    value={guestEmail}
                    onChange={(e) => setGuestEmail(e.target.value)}
                    placeholder="you@email.com"
                    readOnly // keep tied to logged-in user
                />
                {errors.email && <div className="form-error">{errors.email}</div>}
            </div>

            <div>
                <label htmlFor="checkInDate" style={{ color: "black" }}>Check-In</label>
                <input
                    id="checkInDate"
                    type="date"
                    value={checkInDate}
                    onChange={(e) => setCheckInDate(e.target.value)}
                />
                {errors.checkIn && <div className="form-error">{errors.checkIn}</div>}
            </div>

            <div>
                <label htmlFor="checkOutDate" style={{ color: "black" }}>Check-Out</label>
                <input
                    id="checkOutDate"
                    type="date"
                    value={checkOutDate}
                    onChange={(e) => setCheckOutDate(e.target.value)}
                />
                {errors.checkOut && <div className="form-error">{errors.checkOut}</div>}
                {errors.dateOrder && <div className="form-error">{errors.dateOrder}</div>}
            </div>

            <div className="booking-form-actions">
                <button type="submit" className="booking-form-submit" disabled={submitting}>
                    {submitting ? 'Creating…' : 'Create Booking'}
                </button>
                {!!onClose && (
                    <button type="button" onClick={onClose} className="booking-form-close">Close</button>
                )}
            </div>

            {message && (
                <div className={message.includes('success') ? 'success' : 'form-error'} style={{ marginTop: '1rem' }}>
                    {message}
                </div>
            )}
        </form>
    );
}
