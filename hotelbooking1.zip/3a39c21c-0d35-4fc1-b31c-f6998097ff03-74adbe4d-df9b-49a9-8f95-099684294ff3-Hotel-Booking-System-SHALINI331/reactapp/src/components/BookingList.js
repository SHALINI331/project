import React, { useEffect, useState } from 'react';
import { getBookings } from '../utils/api';

const STATUS_MAP = {
    PENDING: { text: 'Pending', color: '#facc15' },
    APPROVED: { text: 'Approved', color: '#22c55e' },
    REJECTED: { text: 'Rejected', color: '#ef4444' },
};

export default function BookingList() {
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        getBookings()
            .then(res => {
                setBookings(res.data || []);
                setLoading(false);
            })
            .catch(() => {
                setError('Could not load bookings');
                setLoading(false);
            });
    }, []);

    if (loading) return <div className="loading">Loading bookings...</div>;
    if (error) return <div className="error">{error}</div>;
    if (bookings.length === 0) return <div style={{ color: '#6366f1', fontWeight: 500 }}>No bookings found</div>;

    const fmt = (d) => d; // backend returns YYYY-MM-DD; show as-is or customize here

    return (
        <div style={{ overflowX: 'auto' }}>
            <table>
                <thead>
                    <tr>
                        <th>Guest</th>
                        <th>Room</th>
                        <th>Check-In</th>
                        <th>Check-Out</th>
                        <th>Total Price</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {bookings.map(b => (
                        <tr key={b.bookingId}>
                            <td>{b.guestName}</td>
                            <td>{b.room?.roomNumber}</td>
                            <td>{fmt(b.checkInDate)}</td>
                            <td>{fmt(b.checkOutDate)}</td>
                            <td>₹{b.totalPrice}</td>
                            <td>
                                <span
                                    style={{
                                        background: STATUS_MAP[b.status]?.color || '#aaa',
                                        color: '#fff',
                                        borderRadius: '0.7rem',
                                        padding: '0.3rem 1rem',
                                        fontWeight: 600,
                                        fontSize: '0.98rem',
                                        letterSpacing: 1
                                    }}
                                >
                                    {STATUS_MAP[b.status]?.text || b.status}
                                </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
