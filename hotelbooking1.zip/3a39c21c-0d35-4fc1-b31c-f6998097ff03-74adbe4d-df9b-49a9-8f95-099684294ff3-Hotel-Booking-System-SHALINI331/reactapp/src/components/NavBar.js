import React from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { AppBar, Toolbar, Typography, Button, Stack, Chip, Avatar } from "@mui/material";
import { AdminPanelSettings, Person } from "@mui/icons-material";
import { useAuth } from "../context/AuthContext";

export default function NavBar() {
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <AppBar position="sticky" color="transparent" sx={{ backdropFilter: "blur(8px)", borderBottom: "1px solid", borderColor: "divider" }}>
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        <Stack direction="row" spacing={1} alignItems="center">
          <img src="/logo192.png" alt="StayEase Logo" width={28} height={28} style={{ borderRadius: 6 }} />
          <Typography component={Link} to="/" color="inherit" sx={{ fontWeight: 800, textDecoration: "none" }}>
            StayEase
          </Typography>
        </Stack>

        <Stack direction="row" spacing={2} alignItems="center">
          <Button component={NavLink} to="/" color="inherit">Home</Button>
          <Button component={NavLink} to="/rooms" color="inherit">Rooms</Button>
          <Button component={NavLink} to="/about" color="inherit">About</Button>
          <Button component={NavLink} to="/contact" color="inherit">Contact</Button>

          {!currentUser ? (
            <>
              <Button component={NavLink} to="/login" variant="outlined">Login</Button>
              <Button component={NavLink} to="/register" variant="contained">Register</Button>
            </>
          ) : (
            <>
              <Stack direction="row" spacing={1} alignItems="center">
                <Chip
                  icon={currentUser.role === "ADMIN" ? <AdminPanelSettings /> : <Person />}
                  label={`${currentUser.name} (${currentUser.role})`}
                  color={currentUser.role === "ADMIN" ? "error" : "primary"}
                  variant="outlined"
                  size="small"
                />
                <Button
                  onClick={() => navigate(currentUser.role === "ADMIN" ? "/admin" : "/dashboard")}
                  variant="contained"
                  color={currentUser.role === "ADMIN" ? "error" : "primary"}
                  size="small"
                >
                  {currentUser.role === "ADMIN" ? "Admin Panel" : "My Dashboard"}
                </Button>
                <Button onClick={handleLogout} color="error" variant="outlined" size="small">
                  Logout
                </Button>
              </Stack>
            </>
          )}
        </Stack>
      </Toolbar>
    </AppBar>
  );
}
