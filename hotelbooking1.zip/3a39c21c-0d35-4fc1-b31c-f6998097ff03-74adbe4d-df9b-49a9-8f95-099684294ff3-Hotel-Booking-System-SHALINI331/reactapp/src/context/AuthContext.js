import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

const AuthContext = createContext(null);

const LOCAL_STORAGE_KEYS = {
  user: 'user', // Match the key used in Login.js
  users: 'hotel_app_registered_users'
};

function getStoredUsers() {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEYS.users);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function setStoredUsers(users) {
  localStorage.setItem(LOCAL_STORAGE_KEYS.users, JSON.stringify(users));
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(LOCAL_STORAGE_KEYS.user);
      if (raw) {
        const user = JSON.parse(raw);
        setCurrentUser(user);
      }
    } catch (error) {
      console.error('Error loading user from localStorage:', error);
      localStorage.removeItem(LOCAL_STORAGE_KEYS.user);
    }
  }, []);

  const login = async (email, password, role) => {
    try {
      // Get the latest user data from localStorage
      const raw = localStorage.getItem(LOCAL_STORAGE_KEYS.user);
      if (raw) {
        const user = JSON.parse(raw);
        // Immediately update current user state
        setCurrentUser(user);
        return { ok: true };
      }
      return { ok: false, message: 'Login failed' };
    } catch (error) {
      console.error('Error in login:', error);
      return { ok: false, message: 'Login failed' };
    }
  };

  const register = (name, email, password) => {
    const users = getStoredUsers();
    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, message: 'Email already registered' };
    }
    const newUser = { name, email, password };
    setStoredUsers([...users, newUser]);
    return { ok: true };
  };

  const logout = () => {
    // Clear all application data on logout
    localStorage.clear();
    setCurrentUser(null);
  };

  const value = useMemo(() => ({ currentUser, login, logout, register }), [currentUser]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

